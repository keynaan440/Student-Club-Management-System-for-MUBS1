<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'club_admin') {
    header("Location: login.php");
    exit();
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'keynan');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get club information using prepared statement
$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT id, club_name FROM clubs WHERE admin_username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$club_result = $stmt->get_result();

// Check if club exists - redirect to club creation if not
// if (!$club_result || $club_result->num_rows == 0) {
//     header("Location: create_club.php");
//     exit();
// }

$club_info = $club_result->fetch_assoc();
$club_id = $club_info['id'];
$club_name = $club_info['club_name'];
$stmt->close();

// Handle member actions (approve, delete, update status)
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $member_id = intval($_POST['member_id'] ?? 0);
    
    switch ($_POST['action']) {
        case 'approve':
            $stmt = $conn->prepare("UPDATE club_members SET status = 'active' WHERE id = ? AND club_id = ?");
            $stmt->bind_param("ii", $member_id, $club_id);
            if ($stmt->execute()) {
                $success_message = "Member approved successfully!";
            } else {
                $error_message = "Error approving member: " . $stmt->error;
            }
            $stmt->close();
            break;
            
        case 'delete':
            $stmt = $conn->prepare("DELETE FROM club_members WHERE id = ? AND club_id = ?");
            $stmt->bind_param("ii", $member_id, $club_id);
            if ($stmt->execute()) {
                $success_message = "Member deleted successfully!";
            } else {
                $error_message = "Error deleting member: " . $stmt->error;
            }
            $stmt->close();
            break;
        
        case 'update_status':
            $new_status = $_POST['status'] ?? '';
            if (in_array($new_status, ['active', 'inactive', 'pending'])) {
                $stmt = $conn->prepare("UPDATE club_members SET status = ? WHERE id = ? AND club_id = ?");
                $stmt->bind_param("sii", $new_status, $member_id, $club_id);
                if ($stmt->execute()) {
                    $success_message = "Member status updated successfully!";
                } else {
                    $error_message = "Error updating member status: " . $stmt->error;
                }
                $stmt->close();
            }
            break;
        
        case 'update_membership':
            $new_membership = $_POST['membership_type'] ?? '';
            if (in_array($new_membership, ['regular', 'premium', 'vip'])) {
                $stmt = $conn->prepare("UPDATE club_members SET membership_type = ? WHERE id = ? AND club_id = ?");
                $stmt->bind_param("sii", $new_membership, $member_id, $club_id);
                if ($stmt->execute()) {
                    $success_message = "Membership type updated successfully!";
                } else {
                    $error_message = "Error updating membership type: " . $stmt->error;
                }
                $stmt->close();
            }
            break;
    }
}

// Get all members for this club
$members_query = "SELECT id, first_name, last_name, email, phone, membership_type, status, join_date, last_login 
                  FROM club_members 
                  WHERE club_id = ? 
                  ORDER BY 
                    CASE WHEN status = 'pending' THEN 0 ELSE 1 END, 
                    join_date DESC";
$stmt = $conn->prepare($members_query);
$stmt->bind_param("i", $club_id);
$stmt->execute();
$members_result = $stmt->get_result();

// Get member statistics
$stats_query = "SELECT 
    COUNT(*) as total_members,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_members,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_members,
    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_members
    FROM club_members WHERE club_id = ?";
$stmt_stats = $conn->prepare($stats_query);
$stmt_stats->bind_param("i", $club_id);
$stmt_stats->execute();
$stats_result = $stmt_stats->get_result();
$stats = $stats_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Members - <?php echo htmlspecialchars($club_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .stat-card {
            text-align: center;
            padding: 15px;
        }
        .stat-card .stat-value {
            font-size: 2rem;
            font-weight: bold;
        }
        .badge-membership {
            font-size: 0.8em;
        }
        .member-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #6c757d;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-none d-md-block sidebar">
            <div class="sidebar-sticky pt-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Club Admin</h4>
                    <div class="text-white small"><?php echo htmlspecialchars($club_name); ?></div>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="club_admin.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="club_members.php">
                            <i class="fas fa-users me-2"></i>Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_events.php">
                            <i class="fas fa-calendar-alt me-2"></i>Events
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_finances.php">
                            <i class="fas fa-money-bill-wave me-2"></i>Finances
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_settings.php">
                            <i class="fas fa-cog me-2"></i>Club Settings
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="fas fa-users me-2"></i>Club Members</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <a href="add_member.php" class="btn btn-primary">
                            <i class="fas fa-user-plus me-1"></i>Add Member
                        </a>
                        <a href="approve_members.php" class="btn btn-success ms-2">
                            <i class="fas fa-user-check me-1"></i>Approve Members
                        </a>
                    </div>
                </div>
            </div>

            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i><?php echo $success_message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i><?php echo $error_message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Member Statistics -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h6 class="card-title">Total Members</h6>
                            <div class="stat-value text-primary"><?php echo $stats['total_members'] ?? 0; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h6 class="card-title">Active Members</h6>
                            <div class="stat-value text-success"><?php echo $stats['active_members'] ?? 0; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h6 class="card-title">Pending Members</h6>
                            <div class="stat-value text-warning"><?php echo $stats['pending_members'] ?? 0; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h6 class="card-title">Inactive Members</h6>
                            <div class="stat-value text-secondary"><?php echo $stats['inactive_members'] ?? 0; ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Members Table -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Member Directory</h5>
                </div>
                <div class="card-body">
                    <?php if ($members_result->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table id="membersTable" class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Member</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Membership</th>
                                    <th>Status</th>
                                    <th>Join Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($member = $members_result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="member-avatar me-3">
                                                <?php echo strtoupper(substr($member['first_name'], 0, 1) . substr($member['last_name'], 0, 1)); ?>
                                            </div>
                                            <div>
                                                <div class="fw-bold"><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></div>
                                                <small class="text-muted">ID: <?php echo $member['id']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($member['email']); ?></td>
                                    <td><?php echo htmlspecialchars($member['phone'] ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="badge badge-membership <?php 
                                            echo $member['membership_type'] == 'vip' ? 'bg-purple' : 
                                                ($member['membership_type'] == 'premium' ? 'bg-primary' : 'bg-secondary'); 
                                        ?>">
                                            <?php echo ucfirst($member['membership_type']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge <?php 
                                            echo $member['status'] == 'active' ? 'bg-success' : 
                                                ($member['status'] == 'pending' ? 'bg-warning' : 'bg-secondary'); 
                                        ?>">
                                            <?php echo ucfirst($member['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M j, Y', strtotime($member['join_date'])); ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <?php if ($member['status'] == 'pending'): ?>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="member_id" value="<?php echo $member['id']; ?>">
                                                    <button type="submit" name="action" value="approve" class="btn btn-success">
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editMemberModal" 
                                                onclick="setEditModal(<?php echo $member['id']; ?>, '<?php echo $member['status']; ?>', '<?php echo $member['membership_type']; ?>')">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteMemberModal" 
                                                onclick="setDeleteModal(<?php echo $member['id']; ?>, '<?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                        <div class="alert alert-info text-center">
                            <i class="fas fa-users fa-3x mb-3 text-muted"></i>
                            <h5>No Members Found</h5>
                            <p>Your club doesn't have any members yet. Start by adding your first member!</p>
                            <a href="add_member.php" class="btn btn-primary">
                                <i class="fas fa-user-plus me-1"></i>Add First Member
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Edit Member Modal -->
<div class="modal fade" id="editMemberModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Member</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="member_id" id="edit_member_id">
                    
                    <div class="mb-3">
                        <label for="edit_status" class="form-label">Status</label>
                        <select class="form-select" name="status" id="edit_status">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="pending">Pending</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_membership" class="form-label">Membership Type</label>
                        <select class="form-select" name="membership_type" id="edit_membership">
                            <option value="regular">Regular</option>
                            <option value="premium">Premium</option>
                            <option value="vip">VIP</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="update_status" class="btn btn-primary">Save Status</button>
                    <button type="submit" name="action" value="update_membership" class="btn btn-warning">Save Membership</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteMemberModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete <strong id="delete_member_name"></strong>?</p>
                <p class="text-danger"><small>This action cannot be undone.</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="member_id" id="delete_member_id">
                    <button type="submit" class="btn btn-danger">Delete Member</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    <?php if ($members_result->num_rows > 0): ?>
    $('#membersTable').DataTable({
        "pageLength": 10,
        "order": [[5, "desc"]],
        "columnDefs": [
            { "orderable": false, "targets": [6] }
        ]
    });
    <?php endif; ?>
});

function setEditModal(memberId, currentStatus, currentMembership) {
    document.getElementById('edit_member_id').value = memberId;
    document.getElementById('edit_status').value = currentStatus;
    document.getElementById('edit_membership').value = currentMembership;
}

function setDeleteModal(memberId, memberName) {
    document.getElementById('delete_member_id').value = memberId;
    document.getElementById('delete_member_name').textContent = memberName;
}
</script>
</body>
</html>

<?php 
$stmt->close();
$stmt_stats->close();
$conn->close(); 
?>