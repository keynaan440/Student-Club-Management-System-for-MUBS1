<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'club_admin') {
    header("Location: login.php");
    exit();
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'keynan');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get club information using admin username
$admin_username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT id, club_name FROM clubs WHERE admin_username = ?");
$stmt->bind_param("s", $admin_username);
$stmt->execute();
$club_result = $stmt->get_result();

if (!$club_result || $club_result->num_rows == 0) {
    header("Location: create_club.php");
    exit();
}

$club_info = $club_result->fetch_assoc();
$club_id = $club_info['id'];
$club_name = $club_info['club_name'];
$stmt->close();

// Handle approval actions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve_member'])) {
        $member_id = intval($_POST['member_id']);
        
        $stmt = $conn->prepare("UPDATE club_members SET status = 'active' WHERE id = ? AND club_id = ?");
        $stmt->bind_param("ii", $member_id, $club_id);
        
        if ($stmt->execute()) {
            $success_message = "Member approved successfully!";
        } else {
            $error_message = "Error approving member: " . $stmt->error;
        }
        $stmt->close();
    }
    elseif (isset($_POST['approve_all'])) {
        $stmt = $conn->prepare("UPDATE club_members SET status = 'active' WHERE club_id = ? AND status = 'pending'");
        $stmt->bind_param("i", $club_id);
        
        if ($stmt->execute()) {
            $success_message = "All pending members approved successfully!";
        } else {
            $error_message = "Error approving members: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Get pending members for this club
$pending_query = "SELECT id, first_name, last_name, email, join_date 
                  FROM club_members 
                  WHERE club_id = ? AND status = 'pending' 
                  ORDER BY join_date ASC";
$stmt = $conn->prepare($pending_query);
$stmt->bind_param("i", $club_id);
$stmt->execute();
$pending_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approve Members - <?php echo htmlspecialchars($club_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .member-card {
            border-left: 4px solid #ffc107;
            margin-bottom: 15px;
            transition: transform 0.2s;
        }
        .member-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .member-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: #6c757d;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.5rem;
        }
        .btn-approve {
            background-color: #28a745;
            color: white;
        }
        .empty-state {
            text-align: center;
            padding: 40px 0;
        }
        .empty-state i {
            font-size: 5rem;
            color: #6c757d;
            opacity: 0.5;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<?php include('admin_navbar.php'); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-user-check me-2"></i>Approve Pending Members</h2>
        <div>
            <form method="POST" class="d-inline">
                <button type="submit" name="approve_all" class="btn btn-success">
                    <i class="fas fa-check-double me-1"></i>Approve All
                </button>
            </form>
            <a href="club_members.php" class="btn btn-secondary ms-2">
                <i class="fas fa-arrow-left me-1"></i>Back to Members
            </a>
        </div>
    </div>

    <?php if (!empty($success_message)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (!empty($error_message)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($pending_result->num_rows > 0): ?>
    <div class="row">
        <?php while ($member = $pending_result->fetch_assoc()): ?>
        <div class="col-md-6">
            <div class="card member-card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="member-avatar me-3">
                            <?php echo strtoupper(substr($member['first_name'], 0, 1) . substr($member['last_name'], 0, 1)); ?>
                        </div>
                        <div class="flex-grow-1">
                            <h5 class="card-title mb-1">
                                <?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>
                            </h5>
                            <p class="card-text text-muted mb-1">
                                <i class="fas fa-envelope me-1"></i><?php echo htmlspecialchars($member['email']); ?>
                            </p>
                            <p class="card-text">
                                <small class="text-muted">
                                    Applied on <?php echo date('M j, Y', strtotime($member['join_date'])); ?>
                                </small>
                            </p>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="member_id" value="<?php echo $member['id']; ?>">
                            <button type="submit" name="approve_member" class="btn btn-approve">
                                <i class="fas fa-check me-1"></i>Approve
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-check-circle"></i>
            <h3>No Pending Members</h3>
            <p class="text-muted">There are currently no members waiting for approval.</p>
            <a href="club_members.php" class="btn btn-primary mt-3">
                <i class="fas fa-users me-1"></i>View All Members
            </a>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php 
$stmt->close();
$conn->close(); 
?>