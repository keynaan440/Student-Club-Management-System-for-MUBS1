<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['member_id'])) {
    header('Location: login.php');
    exit;
}

// Database configuration
$db_host = 'localhost';
$db_name = 'keynan';
$db_user = 'root';
$db_pass = '';

// Connect to database
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get member data
$stmt = $pdo->prepare("SELECT * FROM club_members WHERE id = ?");
$stmt->execute([$_SESSION['member_id']]);
$member = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$member) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Define resources based on membership type
$resources = [
    'regular' => [
        ['title' => 'Club Handbook', 'file' => 'handbook_regular.pdf', 'icon' => 'file-pdf'],
        ['title' => 'Event Calendar', 'file' => 'calendar.pdf', 'icon' => 'calendar-alt'],
        ['title' => 'Membership Benefits', 'file' => 'benefits_regular.pdf', 'icon' => 'award']
    ],
    'premium' => [
        ['title' => 'Club Handbook', 'file' => 'handbook_premium.pdf', 'icon' => 'file-pdf'],
        ['title' => 'Event Calendar', 'file' => 'calendar.pdf', 'icon' => 'calendar-alt'],
        ['title' => 'Membership Benefits', 'file' => 'benefits_premium.pdf', 'icon' => 'award'],
        ['title' => 'Exclusive Workshops', 'file' => 'workshops.pdf', 'icon' => 'chalkboard-teacher'],
        ['title' => 'Discount Codes', 'file' => 'discounts.pdf', 'icon' => 'tags']
    ],
    'vip' => [
        ['title' => 'Club Handbook', 'file' => 'handbook_vip.pdf', 'icon' => 'file-pdf'],
        ['title' => 'Event Calendar', 'file' => 'calendar.pdf', 'icon' => 'calendar-alt'],
        ['title' => 'Membership Benefits', 'file' => 'benefits_vip.pdf', 'icon' => 'award'],
        ['title' => 'Exclusive Workshops', 'file' => 'workshops.pdf', 'icon' => 'chalkboard-teacher'],
        ['title' => 'Discount Codes', 'file' => 'discounts.pdf', 'icon' => 'tags'],
        ['title' => 'VIP Event Invitations', 'file' => 'vip_events.pdf', 'icon' => 'star'],
        ['title' => 'Personal Concierge Guide', 'file' => 'concierge.pdf', 'icon' => 'headset']
    ]
];

// Update last login time
$pdo->prepare("UPDATE club_members SET last_login = NOW() WHERE id = ?")->execute([$_SESSION['member_id']]);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Resources</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #f8f9fc;
            --accent-color: #2e59d9;
            --text-color: #5a5c69;
            --light-gray: #dddfeb;
            --dark-gray: #858796;
        }
        
        body { 
            font-family: 'Nunito', Arial, sans-serif; 
            margin: 0; 
            padding: 0; 
            background-color: var(--secondary-color);
            color: var(--text-color);
        }
        
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Side Navigation (same as dashboard) */
        .sidenav {
            width: 250px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            transition: all 0.3s;
            z-index: 10;
        }
        
        .sidenav-header {
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .sidenav-header img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
            border: 3px solid var(--light-gray);
        }
        
        .sidenav-menu {
            padding: 1rem 0;
        }
        
        .nav-title {
            padding: 0 1.5rem;
            margin: 1.5rem 0 1rem;
            font-size: 0.75rem;
            font-weight: 800;
            text-transform: uppercase;
            color: var(--dark-gray);
            letter-spacing: 0.05em;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: var(--primary-color);
            background-color: var(--secondary-color);
        }
        
        .nav-link.active {
            color: var(--primary-color);
            font-weight: 700;
            border-left: 4px solid var(--primary-color);
        }
        
        .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            overflow-x: hidden;
        }
        
        .topbar {
            height: 70px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }
        
        .topbar h1 {
            font-size: 1.5rem;
            margin: 0;
            color: var(--primary-color);
        }
        
        .user-menu {
            display: flex;
            align-items: center;
        }
        
        .user-menu img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .logout-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background: var(--accent-color);
        }
        
        .container-fluid {
            padding: 2rem;
        }
        
        /* Resources Styles */
        .resources-container {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        }
        
        .resources-header {
            margin-bottom: 2rem;
        }
        
        .resources-header h2 {
            color: var(--primary-color);
            margin-top: 0;
            display: flex;
            align-items: center;
        }
        
        .resources-header h2 i {
            margin-right: 10px;
        }
        
        .resources-header p {
            color: var(--dark-gray);
        }
        
        .resources-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .resource-card {
            border: 1px solid var(--light-gray);
            border-radius: 8px;
            padding: 1.5rem;
            transition: all 0.3s;
        }
        
        .resource-card:hover {
            border-color: var(--primary-color);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
            transform: translateY(-5px);
        }
        
        .resource-icon {
            font-size: 2rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }
        
        .resource-title {
            font-weight: 600;
            margin: 0 0 0.5rem 0;
            color: var(--text-color);
        }
        
        .resource-download {
            display: inline-block;
            margin-top: 1rem;
            padding: 0.5rem 1rem;
            background-color: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9rem;
            transition: background-color 0.3s;
        }
        
        .resource-download:hover {
            background-color: var(--accent-color);
        }
        
        .membership-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            background-color: var(--primary-color);
            color: white;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 10px;
        }
        
        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }
            
            .sidenav {
                width: 100%;
                height: auto;
            }
            
            .resources-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Side Navigation -->
        <div class="sidenav">
            <div class="sidenav-header">
                <img src="<?php echo htmlspecialchars($member['profile_pic'] ?: 'default-profile.jpg'); ?>" alt="Profile Picture">
                <h3><?php echo htmlspecialchars($member['first_name']); ?></h3>
                <p><?php echo ucfirst($member['membership_type']); ?> Member</p>
            </div>
            
            <div class="sidenav-menu">
                <div class="nav-title">Navigation</div>
                
                <div class="nav-item">
                    <a href="member_dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="club_calendar.php" class="nav-link">
                        <i class="fas fa-calendar-alt"></i>
                        <span>Events Calendar</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="resources.php" class="nav-link active">
                        <i class="fas fa-book"></i>
                        <span>Member Resources</span>
                    </a>
                </div>
                
                <div class="nav-title">Account</div>
                
                <div class="nav-item">
                    <a href="edit_member_profile.php" class="nav-link">
                        <i class="fas fa-user-edit"></i>
                        <span>Edit Profile</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="change_password.php" class="nav-link">
                        <i class="fas fa-key"></i>
                        <span>Change Password</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="membership_upgrade.php" class="nav-link">
                        <i class="fas fa-star"></i>
                        <span>Upgrade Membership</span>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="topbar">
                <h1>Member Resources</h1>
                <div class="user-menu">
                    <img src="<?php echo htmlspecialchars($member['profile_pic'] ?: 'default-profile.jpg'); ?>" alt="Profile Picture">
                    <form action="logout.php" method="post">
                        <button type="submit" class="logout-btn">Logout</button>
                    </form>
                </div>
            </div>
            
            <div class="container-fluid">
                <div class="resources-container">
                    <div class="resources-header">
                        <h2><i class="fas fa-book-open"></i> Available Resources</h2>
                        <p>As a <?php echo $member['membership_type']; ?> member, you have access to the following resources:</p>
                    </div>
                    
                    <div class="resources-grid">
                        <?php foreach ($resources[$member['membership_type']] as $resource): ?>
                            <div class="resource-card">
                                <div class="resource-icon">
                                    <i class="fas fa-<?php echo $resource['icon']; ?>"></i>
                                </div>
                                <h3 class="resource-title"><?php echo $resource['title']; ?></h3>
                                <a href="download.php?file=<?php echo urlencode($resource['file']); ?>" class="resource-download">
                                    <i class="fas fa-download"></i> Download
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>