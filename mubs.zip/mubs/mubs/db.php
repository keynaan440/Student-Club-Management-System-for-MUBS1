<?php
$host = 'localhost'; // Your database host
$dbname = 'keynan'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

$mysqli = new mysqli($host, $username, $password, $dbname);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>