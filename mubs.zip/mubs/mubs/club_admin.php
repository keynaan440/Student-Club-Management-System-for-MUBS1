<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'club_admin') {
    header("Location: login.php");
    exit();
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // Default XAMPP username
define('DB_PASS', '');     // Default XAMPP password
define('DB_NAME', 'keynan'); // Replace with your database name

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$club_name = "Your Club"; // Default name
$member_count = 0;
$upcoming_events = array();
$recent_activities = array();

// Get club information
$username = $_SESSION['username'];
$result = $conn->query("SELECT club_name FROM clubs WHERE admin_username = '$username'");
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $club_name = $row['club_name'];
}
$result->free();

// Get member count
$result = $conn->query("SELECT COUNT(*) AS count FROM club_members WHERE club_id IN (SELECT id FROM clubs WHERE admin_username = '$username')");
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $member_count = $row['count'];
}
$result->free();

// Get upcoming events (next 7 days)
$result = $conn->query("SELECT * FROM club_events 
                       WHERE club_id IN (SELECT id FROM clubs WHERE admin_username = '$username')
                       AND event_date BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)
                       ORDER BY event_date ASC LIMIT 3");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $upcoming_events[] = $row;
    }
}
$result->free();

// Get recent activities
$result = $conn->query("SELECT * FROM club_activities 
                       WHERE club_id IN (SELECT id FROM clubs WHERE admin_username = '$username')
                       ORDER BY activity_date DESC LIMIT 5");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $recent_activities[] = $row;
    }
}
$result->free();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .stat-card {
            text-align: center;
            padding: 20px;
        }
        .stat-card .stat-value {
            font-size: 2.5rem;
            font-weight: bold;
        }
        main {
            padding-top: 20px;
        }
        .club-header {
            background-color: #6c757d;
            color: white;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-none d-md-block sidebar">
            <div class="sidebar-sticky pt-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Club Admin</h4>
                    <div class="text-white small"><?php echo htmlspecialchars($club_name); ?></div>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="club_admin.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_members.php">
                            <i class="fas fa-users me-2"></i>Members
                        </a>
                    </li>
                                        <li class="nav-item">
                        <a class="nav-link" href="club_members.php">
                            <i class="fas fa-users me-2"></i>approve Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_events.php">
                            <i class="fas fa-calendar-alt me-2"></i>Events
                        </a>
                    </li>
                    <li class="nav-item">
    <a class="nav-link" href="club_sponsors.php">
        <i class="fas fa-handshake me-2"></i>Sponsors
    </a>
</li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_finances.php">
                            <i class="fas fa-money-bill-wave me-2"></i>Finances
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_settings.php">
                            <i class="fas fa-cog me-2"></i>Club Settings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_reports.php">
                            <i class="fas fa-chart-bar me-2"></i>Reports
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Club Dashboard</h1>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['username']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
                        <li><a class="dropdown-item" href="club_profile.php"><i class="fas fa-user me-1"></i> Profile</a></li>
                        <li><a class="dropdown-item" href="club_settings.php"><i class="fas fa-cog me-1"></i> Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a></li>
                    </ul>
                </div>
            </div>

            <!-- Club Header -->
            <div class="club-header">
                <h3><i class="fas fa-users me-2"></i><?php echo htmlspecialchars($club_name); ?></h3>
                <p class="mb-0">Welcome back! Here's what's happening with your club.</p>
            </div>

            <!-- Stats Cards -->
            <div class="row">
                <div class="col-md-4">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h5 class="card-title">Total Members</h5>
                            <div class="stat-value text-primary"><?php echo $member_count; ?></div>
                            <p class="text-muted"><i class="fas fa-arrow-up text-success"></i> 5 new this month</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h5 class="card-title">Upcoming Events</h5>
                            <div class="stat-value text-success"><?php echo count($upcoming_events); ?></div>
                            <p class="text-muted">Next 7 days</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h5 class="card-title">Club Status</h5>
                            <div class="stat-value text-info">Active</div>
                            <p class="text-muted">Last activity: <?php echo date('M j, Y'); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Upcoming Events -->
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-calendar-alt me-2"></i>Upcoming Events</h5>
                            <a href="club_events.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($upcoming_events)): ?>
                                <div class="list-group">
                                    <?php foreach ($upcoming_events as $event): ?>
                                        <a href="club_event.php?id=<?php echo $event['id']; ?>" class="list-group-item list-group-item-action">
                                            <div class="d-flex w-100 justify-content-between">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($event['event_name']); ?></h6>
                                                <small><?php echo date('M j', strtotime($event['event_date'])); ?></small>
                                            </div>
                                            <p class="mb-1"><?php echo htmlspecialchars(substr($event['description'], 0, 100)); ?>...</p>
                                            <small><?php echo htmlspecialchars($event['location']); ?></small>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i>No upcoming events scheduled.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                

                <!-- Recent Activities -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-history me-2"></i>Recent Activities</h5>
                            <a href="club_activities.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($recent_activities)): ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Activity</th>
                                                <th>Participants</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($recent_activities as $activity): ?>
                                                <tr>
                                                    <td><?php echo date('M j', strtotime($activity['activity_date'])); ?></td>
                                                    <td><?php echo htmlspecialchars($activity['activity_name']); ?></td>
                                                    <td><?php echo $activity['participant_count'] ?? 'N/A'; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i>No recent activities recorded.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="row g-2">
                        <div class="col-md-3">
                            <a href="add_member.php" class="btn btn-primary w-100">
                                <i class="fas fa-user-plus me-2"></i>Add Member
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="create_event.php" class="btn btn-success w-100">
                                <i class="fas fa-calendar-plus me-2"></i>Create Event
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="send_announcement.php" class="btn btn-info w-100">
                                <i class="fas fa-bullhorn me-2"></i>Send Announcement
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="generate_report.php" class="btn btn-warning w-100">
                                <i class="fas fa-file-alt me-2"></i>Generate Report
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('table').DataTable({
            "pageLength": 5,
            "lengthChange": false,
            "searching": false,
            "info": false
        });
    });
</script>
</body>
</html>