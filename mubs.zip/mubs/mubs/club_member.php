<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'club_member') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Member Dashboard</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1>Welcome, Club Member!</h1>
    <p>As a club member, you can view activities and participate in events.</p>
    <p>Stay engaged and enjoy your membership!</p>
    <a href="logout.php" class="btn btn-danger">Logout</a>
</div>
</body>
</html>