<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'club_admin') {
    header("Location: login.php");
    exit();
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'keynan');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get club information
$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT * FROM clubs WHERE admin_username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $club = $result->fetch_assoc();
    $club_id = $club['id'];
    $club_name = $club['club_name'];
} else {
    die("Error: Club not found for this admin.");
}
$stmt->close();

// Initialize variables
$error = '';
$success = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle different setting sections
    if (isset($_POST['update_basic_info'])) {
        // Update basic club information
        $new_club_name = trim($_POST['club_name']);
        $description = trim($_POST['description']);
        $contact_email = trim($_POST['contact_email']);
        
        if (empty($new_club_name)) {
            $error = "Club name cannot be empty";
        } else {
            $stmt = $conn->prepare("UPDATE clubs SET club_name = ?, description = ?, contact_email = ? WHERE id = ?");
            $stmt->bind_param("sssi", $new_club_name, $description, $contact_email, $club_id);
            
            if ($stmt->execute()) {
                $success = "Club information updated successfully!";
                $club['club_name'] = $new_club_name;
                $club['description'] = $description;
                $club['contact_email'] = $contact_email;
            } else {
                $error = "Error updating club information: " . $stmt->error;
            }
            $stmt->close();
        }
    } elseif (isset($_POST['update_privacy'])) {
        // Update privacy settings
        $member_visibility = $_POST['member_visibility'] ?? 'private';
        $event_visibility = $_POST['event_visibility'] ?? 'private';
        
        $stmt = $conn->prepare("UPDATE clubs SET member_visibility = ?, event_visibility = ? WHERE id = ?");
        $stmt->bind_param("ssi", $member_visibility, $event_visibility, $club_id);
        
        if ($stmt->execute()) {
            $success = "Privacy settings updated successfully!";
            $club['member_visibility'] = $member_visibility;
            $club['event_visibility'] = $event_visibility;
        } else {
            $error = "Error updating privacy settings: " . $stmt->error;
        }
        $stmt->close();
    } elseif (isset($_POST['update_notifications'])) {
        // Update notification preferences
        $event_notifications = isset($_POST['event_notifications']) ? 1 : 0;
        $member_notifications = isset($_POST['member_notifications']) ? 1 : 0;
        $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
        
        $stmt = $conn->prepare("UPDATE clubs SET event_notifications = ?, member_notifications = ?, email_notifications = ? WHERE id = ?");
        $stmt->bind_param("iiii", $event_notifications, $member_notifications, $email_notifications, $club_id);
        
        if ($stmt->execute()) {
            $success = "Notification preferences updated successfully!";
            $club['event_notifications'] = $event_notifications;
            $club['member_notifications'] = $member_notifications;
            $club['email_notifications'] = $email_notifications;
        } else {
            $error = "Error updating notification preferences: " . $stmt->error;
        }
        $stmt->close();
    } elseif (isset($_POST['transfer_ownership'])) {
        // Handle ownership transfer request
        $new_admin_username = trim($_POST['new_admin_username']);
        
        // Verify the new admin exists and is a club member
        $stmt = $conn->prepare("SELECT id FROM club_members WHERE email = ? AND club_id = ? AND role = 'club_admin'");
        $stmt->bind_param("si", $new_admin_username, $club_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $stmt = $conn->prepare("UPDATE clubs SET admin_username = ? WHERE id = ?");
            $stmt->bind_param("si", $new_admin_username, $club_id);
            
            if ($stmt->execute()) {
                // Success - log out the current admin
                session_destroy();
                header("Location: login.php?transfer=success");
                exit();
            } else {
                $error = "Error transferring ownership: " . $stmt->error;
            }
        } else {
            $error = "The specified user is not an admin member of this club";
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Settings - <?php echo htmlspecialchars($club_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .settings-section {
            margin-bottom: 30px;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 20px;
        }
        .settings-header {
            border-bottom: 1px solid #dee2e6;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .club-logo-preview {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #6c757d;
            margin-bottom: 15px;
        }
        .danger-zone {
            border: 1px solid #dc3545;
            border-left: 4px solid #dc3545;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-none d-md-block sidebar">
            <div class="sidebar-sticky pt-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Club Admin</h4>
                    <div class="text-white small"><?php echo htmlspecialchars($club_name); ?></div>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="club_admin.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_members.php">
                            <i class="fas fa-users me-2"></i>Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_events.php">
                            <i class="fas fa-calendar-alt me-2"></i>Events
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="club_settings.php">
                            <i class="fas fa-cog me-2"></i>Settings
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="fas fa-cog me-2"></i>Club Settings</h1>
            </div>

            <!-- Error/Success Messages -->
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Basic Information Section -->
            <div class="settings-section">
                <div class="settings-header">
                    <h3><i class="fas fa-info-circle me-2"></i>Basic Information</h3>
                </div>
                
                <form method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-4 text-center">
                            <img src="<?php echo !empty($club['logo_url']) ? htmlspecialchars($club['logo_url']) : 'https://via.placeholder.com/150'; ?>" 
                                 alt="Club Logo" class="club-logo-preview" id="logoPreview">
                            <div class="mt-2">
                                <input type="file" id="logoUpload" name="logo" accept="image/*" style="display: none;">
                                <button type="button" class="btn btn-sm btn-outline-primary" onclick="document.getElementById('logoUpload').click()">
                                    <i class="fas fa-upload me-1"></i>Upload Logo
                                </button>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label for="club_name" class="form-label">Club Name</label>
                                <input type="text" class="form-control" id="club_name" name="club_name" 
                                       value="<?php echo htmlspecialchars($club['club_name']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($club['description'] ?? ''); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="contact_email" class="form-label">Contact Email</label>
                                <input type="email" class="form-control" id="contact_email" name="contact_email" 
                                       value="<?php echo htmlspecialchars($club['contact_email'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="text-end">
                        <button type="submit" name="update_basic_info" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Save Changes
                        </button>
                    </div>
                </form>
            </div>

            <!-- Privacy Settings Section -->
            <div class="settings-section">
                <div class="settings-header">
                    <h3><i class="fas fa-lock me-2"></i>Privacy Settings</h3>
                </div>
                
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Member Directory Visibility</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="member_visibility" id="member_public" 
                                   value="public" <?php echo ($club['member_visibility'] ?? 'private') === 'public' ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="member_public">
                                Public (Visible to everyone)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="member_visibility" id="member_private" 
                                   value="private" <?php echo ($club['member_visibility'] ?? 'private') === 'private' ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="member_private">
                                Private (Visible only to members)
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Event Visibility</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="event_visibility" id="event_public" 
                                   value="public" <?php echo ($club['event_visibility'] ?? 'private') === 'public' ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="event_public">
                                Public (Visible to everyone)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="event_visibility" id="event_private" 
                                   value="private" <?php echo ($club['event_visibility'] ?? 'private') === 'private' ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="event_private">
                                Private (Visible only to members)
                            </label>
                        </div>
                    </div>
                    
                    <div class="text-end">
                        <button type="submit" name="update_privacy" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Save Changes
                        </button>
                    </div>
                </form>
            </div>

            <!-- Notification Preferences Section -->
            <div class="settings-section">
                <div class="settings-header">
                    <h3><i class="fas fa-bell me-2"></i>Notification Preferences</h3>
                </div>
                
                <form method="POST">
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="event_notifications" name="event_notifications" 
                                   <?php echo ($club['event_notifications'] ?? 1) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="event_notifications">
                                Receive event notifications
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="member_notifications" name="member_notifications" 
                                   <?php echo ($club['member_notifications'] ?? 1) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="member_notifications">
                                Receive member activity notifications
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="email_notifications" name="email_notifications" 
                                   <?php echo ($club['email_notifications'] ?? 1) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="email_notifications">
                                Receive email notifications
                            </label>
                        </div>
                    </div>
                    
                    <div class="text-end">
                        <button type="submit" name="update_notifications" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Save Changes
                        </button>
                    </div>
                </form>
            </div>

            <!-- Danger Zone Section -->
            <div class="settings-section danger-zone">
                <div class="settings-header">
                    <h3 class="text-danger"><i class="fas fa-exclamation-triangle me-2"></i>Danger Zone</h3>
                </div>
                
                <div class="mb-4">
                    <h5>Transfer Club Ownership</h5>
                    <p>Transfer ownership of this club to another admin member. You will lose admin privileges.</p>
                    <form method="POST" id="transferForm">
                        <div class="mb-3">
                            <label for="new_admin_username" class="form-label">New Admin Email</label>
                            <input type="email" class="form-control" id="new_admin_username" name="new_admin_username" 
                                   placeholder="Enter new admin's email address" required>
                        </div>
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#transferModal">
                            <i class="fas fa-user-shield me-1"></i>Transfer Ownership
                        </button>
                    </form>
                </div>
                
                <div>
                    <h5>Delete Club</h5>
                    <p>Permanently delete this club and all its data. This action cannot be undone.</p>
                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteClubModal">
                        <i class="fas fa-trash me-1"></i>Delete Club
                    </button>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Transfer Ownership Modal -->
<div class="modal fade" id="transferModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Ownership Transfer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to transfer ownership of <strong><?php echo htmlspecialchars($club_name); ?></strong>?</p>
                <p class="text-danger"><small>You will lose admin privileges and be logged out immediately.</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="transferForm" name="transfer_ownership" class="btn btn-danger">
                    Confirm Transfer
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Club Modal -->
<div class="modal fade" id="deleteClubModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Club Deletion</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to permanently delete <strong><?php echo htmlspecialchars($club_name); ?></strong>?</p>
                <p class="text-danger"><small>This will delete all club data including members and events. This action cannot be undone.</small></p>
                <div class="mb-3">
                    <label for="confirmClubName" class="form-label">Type the club name to confirm:</label>
                    <input type="text" class="form-control" id="confirmClubName" placeholder="<?php echo htmlspecialchars($club_name); ?>">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteBtn" disabled>
                    <i class="fas fa-trash me-1"></i>Delete Club
                </button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Preview logo before upload
document.getElementById('logoUpload').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            document.getElementById('logoPreview').src = event.target.result;
        };
        reader.readAsDataURL(file);
    }
});

// Confirm club name matches for deletion
document.getElementById('confirmClubName').addEventListener('input', function() {
    const confirmBtn = document.getElementById('confirmDeleteBtn');
    confirmBtn.disabled = this.value !== '<?php echo htmlspecialchars($club_name); ?>';
});

// Handle logo upload via AJAX
document.querySelector('form[enctype="multipart/form-data"]').addEventListener('submit', function(e) {
    const fileInput = document.getElementById('logoUpload');
    if (fileInput.files.length > 0) {
        e.preventDefault();
        const formData = new FormData(this);
        
        fetch('upload_logo.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.submit();
            } else {
                alert('Error uploading logo: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while uploading the logo');
        });
    }
});
</script>
</body>
</html>