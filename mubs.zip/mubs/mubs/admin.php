<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');     
define('DB_NAME', 'keynan');

require_once 'db.php';
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get stats for dashboard
$user_count = 0;
$active_users = 0;
$recent_logs = array();
$new_users = array();
$system_stats = array();
$user_roles = array();
$recent_errors = array();

// Total users count
$result = $conn->query("SELECT COUNT(*) AS count FROM users");
if ($result) {
    $row = $result->fetch_assoc();
    $user_count = $row['count'];
    $result->free();
}

// Active users count
$result = $conn->query("SELECT COUNT(*) AS count FROM users WHERE last_login > DATE_SUB(NOW(), INTERVAL 30 DAY)");
if ($result) {
    $row = $result->fetch_assoc();
    $active_users = $row['count'];
    $result->free();
}

// Recent activity logs
$result = $conn->query("SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 5");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $recent_logs[] = $row;
    }
    $result->free();
}

// New users (last 7 days)
$result = $conn->query("SELECT username, email, created_at FROM users WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY) ORDER BY created_at DESC LIMIT 5");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $new_users[] = $row;
    }
    $result->free();
}

// System statistics
$result = $conn->query("
    SELECT 
        (SELECT COUNT(*) FROM users) AS total_users,
        (SELECT COUNT(*) FROM users WHERE last_login > DATE_SUB(NOW(), INTERVAL 30 DAY)) AS active_users,
        (SELECT COUNT(*) FROM activity_logs WHERE DATE(timestamp) = CURDATE()) AS today_activity,
        (SELECT COUNT(*) FROM error_logs WHERE DATE(timestamp) = CURDATE()) AS today_errors
");
if ($result) {
    $system_stats = $result->fetch_assoc();
    $result->free();
}

// User roles distribution
$result = $conn->query("
    SELECT r.role_name, COUNT(u.id) AS user_count 
    FROM roles r
    LEFT JOIN users u ON r.id = u.role_id
    GROUP BY r.role_name
    ORDER BY user_count DESC
");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $user_roles[] = $row;
    }
    $result->free();
}

// Recent error logs
$result = $conn->query("SELECT * FROM error_logs ORDER BY timestamp DESC LIMIT 5");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $recent_errors[] = $row;
    }
    $result->free();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .stat-card {
            text-align: center;
            padding: 20px;
        }
        .stat-card .stat-value {
            font-size: 2.5rem;
            font-weight: bold;
        }
        .chart-container {
            position: relative;
            height: 300px;
            margin-bottom: 20px;
        }
        .badge-pill {
            padding: 0.5em 0.8em;
        }
        .progress {
            height: 10px;
        }
        .system-health {
            font-weight: bold;
        }
        .health-excellent {
            color: #28a745;
        }
        .health-good {
            color: #17a2b8;
        }
        .health-warning {
            color: #ffc107;
        }
        .health-critical {
            color: #dc3545;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-none d-md-block sidebar">
            <div class="sidebar-sticky pt-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Admin Panel</h4>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users mr-2"></i>User Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="roles.php">
                            <i class="fas fa-user-tag mr-2"></i>Role Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="settings.php">
                            <i class="fas fa-cog mr-2"></i>System Settings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar mr-2"></i>Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logs.php">
                            <i class="fas fa-clipboard-list mr-2"></i>Activity Logs
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="backup.php">
                            <i class="fas fa-database mr-2"></i>Backup/Restore
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="api.php">
                            <i class="fas fa-code mr-2"></i>API Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="notifications.php">
                            <i class="fas fa-bell mr-2"></i>Notifications
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Dashboard</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="dropdown">
                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle mr-1"></i><?php echo htmlspecialchars($_SESSION['username']); ?>
                        </button>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="profile.php"><i class="fas fa-user mr-1"></i> Profile</a>
                            <a class="dropdown-item" href="settings.php"><i class="fas fa-cog mr-1"></i> Settings</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt mr-1"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="row">
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h5 class="card-title">Total Users</h5>
                            <div class="stat-value text-primary"><?php echo $user_count; ?></div>
                            <p class="text-muted"><i class="fas fa-arrow-up text-success"></i> 12% from last month</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h5 class="card-title">Active Users</h5>
                            <div class="stat-value text-success"><?php echo $active_users; ?></div>
                            <p class="text-muted"><i class="fas fa-arrow-up text-success"></i> 8% from last month</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h5 class="card-title">Today's Activity</h5>
                            <div class="stat-value text-info"><?php echo $system_stats['today_activity'] ?? 0; ?></div>
                            <p class="text-muted"><i class="fas fa-arrow-down text-danger"></i> 2% from yesterday</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h5 class="card-title">System Health</h5>
                            <div class="stat-value system-health health-excellent">Excellent</div>
                            <p class="text-muted">Errors today: <?php echo $system_stats['today_errors'] ?? 0; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-chart-line mr-2"></i>User Growth</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="userGrowthChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-chart-pie mr-2"></i>User Roles Distribution</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="rolesDistributionChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tables Row -->
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5><i class="fas fa-users mr-2"></i>New Users (Last 7 Days)</h5>
                            <a href="users.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Username</th>
                                            <th>Email</th>
                                            <th>Joined</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($new_users as $user): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                                            <td><span class="badge badge-pill badge-success">Active</span></td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($new_users)): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">No new users in the last 7 days</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5><i class="fas fa-exclamation-triangle mr-2"></i>Recent System Errors</h5>
                            <a href="error_logs.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Timestamp</th>
                                            <th>Error Type</th>
                                            <th>Message</th>
                                            <th>Severity</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_errors as $error): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars(date('M j, H:i', strtotime($error['timestamp']))); ?></td>
                                            <td><?php echo htmlspecialchars($error['error_type']); ?></td>
                                            <td><?php echo htmlspecialchars(substr($error['message'], 0, 30)) . (strlen($error['message']) > 30 ? '...' : ''); ?></td>
                                            <td>
                                                <?php 
                                                $severity_class = '';
                                                if (stripos($error['severity'], 'critical') !== false) {
                                                    $severity_class = 'danger';
                                                } elseif (stripos($error['severity'], 'warning') !== false) {
                                                    $severity_class = 'warning';
                                                } else {
                                                    $severity_class = 'info';
                                                }
                                                ?>
                                                <span class="badge badge-pill badge-<?php echo $severity_class; ?>">
                                                    <?php echo htmlspecialchars(ucfirst($error['severity'])); ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($recent_errors)): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">No recent errors found</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="card mt-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5><i class="fas fa-history mr-2"></i>Recent Activity</h5>
                    <a href="logs.php" class="btn btn-sm btn-outline-primary">View All Logs</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Timestamp</th>
                                    <th>User</th>
                                    <th>Activity</th>
                                    <th>IP Address</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_logs as $log): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars(date('M j, H:i', strtotime($log['timestamp']))); ?></td>
                                    <td><?php echo htmlspecialchars($log['username']); ?></td>
                                    <td><?php echo htmlspecialchars($log['activity']); ?></td>
                                    <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-info" data-toggle="modal" data-target="#logDetailsModal" 
                                            data-activity="<?php echo htmlspecialchars($log['activity']); ?>"
                                            data-details="<?php echo htmlspecialchars($log['details']); ?>"
                                            data-user="<?php echo htmlspecialchars($log['username']); ?>"
                                            data-time="<?php echo htmlspecialchars(date('M j, Y H:i:s', strtotime($log['timestamp']))); ?>">
                                            View
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (empty($recent_logs)): ?>
                                <tr>
                                    <td colspan="5" class="text-center">No recent activity found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- System Status -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5><i class="fas fa-server mr-2"></i>System Status</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <h6>Database</h6>
                                    <span class="text-success"><i class="fas fa-circle"></i> Online</span>
                                </div>
                                <div class="text-right">
                                    <small class="text-muted">Response</small>
                                    <div>28ms</div>
                                </div>
                            </div>
                            <div class="progress mb-4">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 95%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <h6>Web Server</h6>
                                    <span class="text-success"><i class="fas fa-circle"></i> Online</span>
                                </div>
                                <div class="text-right">
                                    <small class="text-muted">Load</small>
                                    <div>12%</div>
                                </div>
                            </div>
                            <div class="progress mb-4">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 12%" aria-valuenow="12" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <h6>Disk Space</h6>
                                    <span class="text-warning"><i class="fas fa-circle"></i> 65% Used</span>
                                </div>
                                <div class="text-right">
                                    <small class="text-muted">Free</small>
                                    <div>35%</div>
                                </div>
                            </div>
                            <div class="progress mb-4">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 65%" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <h6>Memory</h6>
                                    <span class="text-info"><i class="fas fa-circle"></i> 42% Used</span>
                                </div>
                                <div class="text-right">
                                    <small class="text-muted">Free</small>
                                    <div>2.4GB</div>
                                </div>
                            </div>
                            <div class="progress mb-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 42%" aria-valuenow="42" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card mt-4 mb-4">
                <div class="card-header">
                    <h5><i class="fas fa-bolt mr-2"></i>Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <a href="add_user.php" class="btn btn-primary btn-block mb-2">
                                <i class="fas fa-user-plus mr-2"></i>Add New User
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="backup.php" class="btn btn-info btn-block mb-2">
                                <i class="fas fa-database mr-2"></i>Create Backup
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="system_check.php" class="btn btn-warning btn-block mb-2">
                                <i class="fas fa-heartbeat mr-2"></i>System Check
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="notifications.php" class="btn btn-secondary btn-block mb-2">
                                <i class="fas fa-bell mr-2"></i>Send Notification
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Log Details Modal -->
<div class="modal fade" id="logDetailsModal" tabindex="-1" role="dialog" aria-labelledby="logDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="logDetailsModalLabel">Activity Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <strong>User:</strong> <span id="detail-user"></span>
                    </div>
                    <div class="col-md-6">
                        <strong>Time:</strong> <span id="detail-time"></span>
                    </div>
                </div>
                <div class="mb-3">
                    <strong>Activity:</strong> <span id="detail-activity"></span>
                </div>
                <div>
                    <strong>Details:</strong>
                    <pre id="detail-details" class="bg-light p-3 mt-2" style="white-space: pre-wrap; word-wrap: break-word;"></pre>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
<script>
    $(document).ready(function() {
        // Initialize DataTables
        $('.table').DataTable({
            "pageLength": 5,
            "lengthChange": false,
            "order": [[0, "desc"]]
        });

        // Log details modal
        $('#logDetailsModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            $('#detail-user').text(button.data('user'));
            $('#detail-time').text(button.data('time'));
            $('#detail-activity').text(button.data('activity'));
            $('#detail-details').text(button.data('details'));
        });

        // User Growth Chart
        var userGrowthCtx = document.getElementById('userGrowthChart').getContext('2d');
        var userGrowthChart = new Chart(userGrowthCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'New Users',
                    data: [120, 190, 170, 220, 250, 280, 310, 340, 300, 350, 400, 450],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 2,
                    tension: 0.1,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Roles Distribution Chart
        var rolesDistributionCtx = document.getElementById('rolesDistributionChart').getContext('2d');
        var rolesDistributionChart = new Chart(rolesDistributionCtx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode(array_column($user_roles, 'role_name')); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_column($user_roles, 'user_count')); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.7)',
                        'rgba(54, 162, 235, 0.7)',
                        'rgba(255, 206, 86, 0.7)',
                        'rgba(75, 192, 192, 0.7)',
                        'rgba(153, 102, 255, 0.7)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    position: 'right'
                }
            }
        });
    });
</script>
</body>
</html>