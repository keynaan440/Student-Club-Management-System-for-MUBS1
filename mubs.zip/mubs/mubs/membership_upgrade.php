<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['member_id'])) {
    header('Location: login.php');
    exit;
}

// Database configuration
$db_host = 'localhost';
$db_name = 'keynan';
$db_user = 'root';
$db_pass = '';

// Connect to database
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get member data
$stmt = $pdo->prepare("SELECT * FROM club_members WHERE id = ?");
$stmt->execute([$_SESSION['member_id']]);
$member = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$member) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$errors = [];
$success = false;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['membership_type'])) {
    $new_membership = $_POST['membership_type'];
    
    // Validate membership type
    $allowed_types = ['regular', 'premium', 'vip'];
    if (!in_array($new_membership, $allowed_types)) {
        $errors[] = "Invalid membership type selected";
    }
    
    // Check if upgrade is valid (can't downgrade)
    $current_level = array_search($member['membership_type'], $allowed_types);
    $new_level = array_search($new_membership, $allowed_types);
    
    if ($new_level < $current_level) {
        $errors[] = "You can only upgrade your membership, not downgrade";
    } elseif ($new_level === $current_level) {
        $errors[] = "You already have this membership level";
    }
    
    // Process upgrade if no errors
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("UPDATE club_members SET membership_type = ? WHERE id = ?");
            $stmt->execute([$new_membership, $_SESSION['member_id']]);
            
            $success = true;
            // Refresh member data
            $stmt = $pdo->prepare("SELECT * FROM club_members WHERE id = ?");
            $stmt->execute([$_SESSION['member_id']]);
            $member = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

// Define membership plans
$membership_plans = [
    'regular' => [
        'price' => 'Free',
        'features' => [
            'Access to basic club resources',
            'Monthly newsletter',
            'Entry to regular events',
            'Club member directory'
        ]
    ],
    'premium' => [
        'price' => '$9.99/month',
        'features' => [
            'All regular benefits',
            'Exclusive workshops',
            '15% discount on merchandise',
            'Early event registration',
            'Priority support'
        ]
    ],
    'vip' => [
        'price' => '$24.99/month',
        'features' => [
            'All premium benefits',
            'VIP event access',
            '30% discount on merchandise',
            'Personal concierge service',
            'Free entry to all paid events',
            'Exclusive member gifts'
        ]
    ]
];

// Update last login time
$pdo->prepare("UPDATE club_members SET last_login = NOW() WHERE id = ?")->execute([$_SESSION['member_id']]);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upgrade Membership</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #f8f9fc;
            --accent-color: #2e59d9;
            --text-color: #5a5c69;
            --light-gray: #dddfeb;
            --dark-gray: #858796;
            --success-color: #1cc88a;
            --danger-color: #e74a3b;
        }
        
        body { 
            font-family: 'Nunito', Arial, sans-serif; 
            margin: 0; 
            padding: 0; 
            background-color: var(--secondary-color);
            color: var(--text-color);
        }
        
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Side Navigation (same as dashboard) */
        .sidenav {
            width: 250px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            transition: all 0.3s;
            z-index: 10;
        }
        
        .sidenav-header {
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .sidenav-header img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
            border: 3px solid var(--light-gray);
        }
        
        .sidenav-menu {
            padding: 1rem 0;
        }
        
        .nav-title {
            padding: 0 1.5rem;
            margin: 1.5rem 0 1rem;
            font-size: 0.75rem;
            font-weight: 800;
            text-transform: uppercase;
            color: var(--dark-gray);
            letter-spacing: 0.05em;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: var(--primary-color);
            background-color: var(--secondary-color);
        }
        
        .nav-link.active {
            color: var(--primary-color);
            font-weight: 700;
            border-left: 4px solid var(--primary-color);
        }
        
        .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            overflow-x: hidden;
        }
        
        .topbar {
            height: 70px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }
        
        .topbar h1 {
            font-size: 1.5rem;
            margin: 0;
            color: var(--primary-color);
        }
        
        .user-menu {
            display: flex;
            align-items: center;
        }
        
        .user-menu img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .logout-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background: var(--accent-color);
        }
        
        .container-fluid {
            padding: 2rem;
        }
        
        /* Upgrade Styles */
        .upgrade-container {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        }
        
        .upgrade-header {
            margin-bottom: 2rem;
        }
        
        .upgrade-header h2 {
            color: var(--primary-color);
            margin-top: 0;
            display: flex;
            align-items: center;
        }
        
        .upgrade-header h2 i {
            margin-right: 10px;
        }
        
        .current-membership {
            display: inline-block;
            padding: 0.5rem 1rem;
            background-color: var(--primary-color);
            color: white;
            border-radius: 20px;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .plans-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }
        
        .plan-card {
            border: 1px solid var(--light-gray);
            border-radius: 8px;
            padding: 2rem;
            transition: all 0.3s;
            position: relative;
        }
        
        .plan-card:hover {
            border-color: var(--primary-color);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
        }
        
        .plan-card.current {
            border: 2px solid var(--primary-color);
            background-color: rgba(78, 115, 223, 0.05);
        }
        
        .plan-card.current .plan-badge {
            position: absolute;
            top: -10px;
            right: 20px;
            background-color: var(--primary-color);
            color: white;
            padding: 0.25rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .plan-name {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0 0 0.5rem 0;
            color: var(--text-color);
            text-transform: capitalize;
        }
        
        .plan-price {
            font-size: 1.75rem;
            font-weight: 700;
            margin: 0 0 1.5rem 0;
            color: var(--primary-color);
        }
        
        .plan-features {
            list-style-type: none;
            padding: 0;
            margin: 0 0 1.5rem 0;
        }
        
        .plan-features li {
            padding: 0.5rem 0;
            display: flex;
            align-items: center;
        }
        
        .plan-features li i {
            margin-right: 10px;
            color: var(--primary-color);
        }
        
        .upgrade-btn {
            display: block;
            width: 100%;
            padding: 0.75rem;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            text-align: center;
            text-decoration: none;
        }
        
        .upgrade-btn:hover {
            background-color: var(--accent-color);
        }
        
        .upgrade-btn.disabled {
            background-color: var(--light-gray);
            cursor: not-allowed;
        }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .error-list {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        
        .error-list li {
            color: var(--danger-color);
            margin-bottom: 0.5rem;
        }
        
        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }
            
            .sidenav {
                width: 100%;
                height: auto;
            }
            
            .plans-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Side Navigation -->
        <div class="sidenav">
            <div class="sidenav-header">
                <img src="<?php echo htmlspecialchars($member['profile_pic'] ?: 'default-profile.jpg'); ?>" alt="Profile Picture">
                <h3><?php echo htmlspecialchars($member['first_name']); ?></h3>
                <p><?php echo ucfirst($member['membership_type']); ?> Member</p>
            </div>
            
            <div class="sidenav-menu">
                <div class="nav-title">Navigation</div>
                
                <div class="nav-item">
                    <a href="member_dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="club_calendar.php" class="nav-link">
                        <i class="fas fa-calendar-alt"></i>
                        <span>Events Calendar</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="resources.php" class="nav-link">
                        <i class="fas fa-book"></i>
                        <span>Member Resources</span>
                    </a>
                </div>
                
                <div class="nav-title">Account</div>
                
                <div class="nav-item">
                    <a href="edit_member_profile.php" class="nav-link">
                        <i class="fas fa-user-edit"></i>
                        <span>Edit Profile</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="change_password.php" class="nav-link">
                        <i class="fas fa-key"></i>
                        <span>Change Password</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="membership_upgrade.php" class="nav-link active">
                        <i class="fas fa-star"></i>
                        <span>Upgrade Membership</span>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="topbar">
                <h1>Upgrade Membership</h1>
                <div class="user-menu">
                    <img src="<?php echo htmlspecialchars($member['profile_pic'] ?: 'default-profile.jpg'); ?>" alt="Profile Picture">
                    <form action="logout.php" method="post">
                        <button type="submit" class="logout-btn">Logout</button>
                    </form>
                </div>
            </div>
            
            <div class="container-fluid">
                <div class="upgrade-container">
                    <div class="upgrade-header">
                        <h2><i class="fas fa-crown"></i> Membership Plans</h2>
                        <div class="current-membership">
                            Your Current Plan: <?php echo ucfirst($member['membership_type']); ?>
                        </div>
                        <p>Upgrade your membership to unlock more benefits and exclusive features.</p>
                    </div>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            Your membership has been upgraded successfully! You now have <?php echo ucfirst($_POST['membership_type']); ?> benefits.
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <ul class="error-list">
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <div class="plans-container">
                        <?php foreach ($membership_plans as $type => $plan): ?>
                            <div class="plan-card <?php echo $type === $member['membership_type'] ? 'current' : ''; ?>">
                                <?php if ($type === $member['membership_type']): ?>
                                    <div class="plan-badge">Current Plan</div>
                                <?php endif; ?>
                                
                                <h3 class="plan-name"><?php echo ucfirst($type); ?></h3>
                                <p class="plan-price"><?php echo $plan['price']; ?></p>
                                
                                <ul class="plan-features">
                                    <?php foreach ($plan['features'] as $feature): ?>
                                        <li><i class="fas fa-check"></i> <?php echo $feature; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                                
                                <?php if ($type === $member['membership_type']): ?>
                                    <button class="upgrade-btn disabled">Current Plan</button>
                                <?php else: ?>
                                    <form method="POST">
                                        <input type="hidden" name="membership_type" value="<?php echo $type; ?>">
                                        <button type="submit" class="upgrade-btn">
                                            <?php echo array_search($type, array_keys($membership_plans)) > array_search($member['membership_type'], array_keys($membership_plans)) ? 'Upgrade Now' : 'Downgrade'; ?>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>