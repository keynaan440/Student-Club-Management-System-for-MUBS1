<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['member_id'])) {
    header('Location: login.php');
    exit;
}

// Database configuration
$db_host = 'localhost';
$db_name = 'keynan';
$db_user = 'root';
$db_pass = '';

// Connect to database
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get member data
$stmt = $pdo->prepare("SELECT * FROM club_members WHERE id = ?");
$stmt->execute([$_SESSION['member_id']]);
$member = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$member) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Update last login time
$pdo->prepare("UPDATE club_members SET last_login = NOW() WHERE id = ?")->execute([$_SESSION['member_id']]);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Member Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #f8f9fc;
            --accent-color: #2e59d9;
            --text-color: #5a5c69;
            --light-gray: #dddfeb;
            --dark-gray: #858796;
        }
        
        body { 
            font-family: 'Nunito', Arial, sans-serif; 
            margin: 0; 
            padding: 0; 
            background-color: var(--secondary-color);
            color: var(--text-color);
        }
        
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Side Navigation */
        .sidenav {
            width: 250px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            transition: all 0.3s;
            z-index: 10;
        }
        
        .sidenav-header {
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .sidenav-header img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
            border: 3px solid var(--light-gray);
        }
        
        .sidenav-menu {
            padding: 1rem 0;
        }
        
        .nav-title {
            padding: 0 1.5rem;
            margin: 1.5rem 0 1rem;
            font-size: 0.75rem;
            font-weight: 800;
            text-transform: uppercase;
            color: var(--dark-gray);
            letter-spacing: 0.05em;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: var(--primary-color);
            background-color: var(--secondary-color);
        }
        
        .nav-link.active {
            color: var(--primary-color);
            font-weight: 700;
            border-left: 4px solid var(--primary-color);
        }
        
        .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            overflow-x: hidden;
        }
        
        .topbar {
            height: 70px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }
        
        .topbar h1 {
            font-size: 1.5rem;
            margin: 0;
            color: var(--primary-color);
        }
        
        .user-menu {
            display: flex;
            align-items: center;
        }
        
        .user-menu img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .logout-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background: var(--accent-color);
        }
        
        .container-fluid {
            padding: 2rem;
        }
        
        .profile-section {
            display: flex;
            margin-bottom: 30px;
            background: white;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        }
        
        .profile-pic {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 30px;
            border: 5px solid var(--light-gray);
        }
        
        .profile-info {
            flex: 1;
        }
        
        .welcome {
            font-size: 1.75rem;
            margin-bottom: 10px;
            color: var(--primary-color);
        }
        
        .member-status {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 600;
        }
        
        .status-active {
            background: #d4edda;
            color: #155724;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-inactive {
            background: #f8d7da;
            color: #721c24;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .dashboard-card {
            background: white;
            border: none;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0.5rem 1.75rem 0 rgba(58, 59, 69, 0.2);
        }
        
        .card-title {
            font-size: 1.2rem;
            margin-top: 0;
            color: var(--primary-color);
            border-bottom: 1px solid var(--light-gray);
            padding-bottom: 10px;
            display: flex;
            align-items: center;
        }
        
        .card-title i {
            margin-right: 10px;
        }
        
        .card-content {
            margin-top: 15px;
        }
        
        .event-item {
            padding: 10px 0;
            border-bottom: 1px dashed var(--light-gray);
        }
        
        .event-item:last-child {
            border-bottom: none;
        }
        
        .event-date {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .resource-link {
            display: block;
            padding: 8px 0;
            color: var(--primary-color);
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .resource-link:hover {
            color: var(--accent-color);
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }
            
            .sidenav {
                width: 100%;
                height: auto;
            }
            
            .profile-section {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }
            
            .profile-pic {
                margin-right: 0;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Side Navigation -->
        <div class="sidenav">
            <div class="sidenav-header">
                <img src="<?php echo $member['profile_pic'] ? htmlspecialchars($member['profile_pic']) : 'default-profile.jpg'; ?>" alt="Profile Picture">
                <h3><?php echo htmlspecialchars($member['first_name']); ?></h3>
                <p><?php echo ucfirst($member['membership_type']); ?> Member</p>
            </div>
            
            <div class="sidenav-menu">
                <div class="nav-title">Navigation</div>
                
                <div class="nav-item">
                    <a href="#" class="nav-link active">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="club_calendar.php" class="nav-link">
                        <i class="fas fa-calendar-alt"></i>
                        <span>Events Calendar</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="resources.php" class="nav-link">
                        <i class="fas fa-book"></i>
                        <span>Member Resources</span>
                    </a>
                </div>
                
                <div class="nav-title">Account</div>
                
                <div class="nav-item">
                    <a href="edit_member_profile.php" class="nav-link">
                        <i class="fas fa-user-edit"></i>
                        <span>Edit Profile</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="change_password.php" class="nav-link">
                        <i class="fas fa-key"></i>
                        <span>Change Password</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="membership_upgrade.php" class="nav-link">
                        <i class="fas fa-star"></i>
                        <span>Upgrade Membership</span>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="topbar">
                <h1>Member Dashboard</h1>
                <div class="user-menu">
                    <img src="<?php echo $member['profile_pic'] ? htmlspecialchars($member['profile_pic']) : 'default-profile.jpg'; ?>" alt="Profile Picture">
                    <form action="logout.php" method="post">
                        <button type="submit" class="logout-btn">Logout</button>
                    </form>
                </div>
            </div>
            
            <div class="container-fluid">
                <div class="profile-section">
                    <img src="<?php echo $member['profile_pic'] ? htmlspecialchars($member['profile_pic']) : 'default-profile.jpg'; ?>" alt="Profile Picture" class="profile-pic">
                    <div class="profile-info">
                        <h2 class="welcome">Welcome back, <?php echo htmlspecialchars($member['first_name']); ?>!</h2>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($member['email']); ?></p>
                        <p><strong>Member Since:</strong> <?php echo date('F j, Y', strtotime($member['join_date'])); ?></p>
                        <p><strong>Status:</strong> 
                            <span class="member-status status-<?php echo $member['status']; ?>">
                                <?php echo ucfirst($member['status']); ?>
                            </span>
                        </p>
                    </div>
                </div>
                
                <div class="dashboard-grid">
                    <div class="dashboard-card">
                        <h3 class="card-title"><i class="fas fa-calendar-check"></i> Upcoming Events</h3>
                        <div class="card-content">
                            <div class="event-item">
                                <span class="event-date">June 15, 2023</span>
                                <p>Monthly Club Meeting</p>
                            </div>
                            <div class="event-item">
                                <span class="event-date">July 22, 2023</span>
                                <p>Annual Summer Picnic</p>
                            </div>
                            <div class="event-item">
                                <span class="event-date">August 5, 2023</span>
                                <p>Leadership Workshop</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-card">
                        <h3 class="card-title"><i class="fas fa-award"></i> Your Benefits</h3>
                        <div class="card-content">
                            <p>As a <strong><?php echo $member['membership_type']; ?></strong> member, you enjoy:</p>
                            <ul>
                                <?php if ($member['membership_type'] === 'regular'): ?>
                                    <li>Weekly club meetings</li>
                                    <li>Monthly newsletter</li>
                                    <li>Basic event access</li>
                                <?php elseif ($member['membership_type'] === 'premium'): ?>
                                    <li>All regular benefits</li>
                                    <li>Exclusive workshops</li>
                                    <li>15% merchandise discount</li>
                                <?php else: ?>
                                    <li>All premium benefits</li>
                                    <li>VIP event access</li>
                                    <li>Personal concierge</li>
                                    <li>30% merchandise discount</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="dashboard-card">
                        <h3 class="card-title"><i class="fas fa-bell"></i> Notifications</h3>
                        <div class="card-content">
                            <p><strong>Last login:</strong> <?php echo $member['last_login'] ? date('F j, Y g:i a', strtotime($member['last_login'])) : 'First login'; ?></p>
                            <p>You have 3 unread messages</p>
                            <p>Your membership is active</p>
                        </div>
                    </div>
                    
                    <div class="dashboard-card">
                        <h3 class="card-title"><i class="fas fa-book-open"></i> Quick Resources</h3>
                        <div class="card-content">
                            <a href="#" class="resource-link">Club Handbook (PDF)</a>
                            <a href="#" class="resource-link">Event Guidelines</a>
                            <a href="#" class="resource-link">Membership Benefits</a>
                            <a href="#" class="resource-link">FAQ</a>
                            <a href="#" class="resource-link">Contact Committee</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>