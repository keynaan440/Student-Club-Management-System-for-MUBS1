<?php
session_start();
require_once 'db_config.php'; // Ensure this connects to your database

$login_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_or_email = trim($_POST['username']);
    $password = $_POST['password'];

    try {
        // Check in 'users' table first (for admin login)
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = :identifier OR email = :identifier LIMIT 1");
        $stmt->execute([':identifier' => $username_or_email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            // Set session and redirect based on role
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            // Update last login
            $update = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
            $update->execute([':id' => $user['id']]);

            // Redirect admin
            if ($user['role'] === 'club_admin') {
                header("Location: club_admin.php");
                exit();
            }

        } else {
            // Not found in 'users', try in 'club_members'
            $stmt = $conn->prepare("SELECT * FROM club_members WHERE email = :identifier LIMIT 1");
            $stmt->execute([':identifier' => $username_or_email]);
            $member = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($member && password_verify($password, $member['password'])) {
                $_SESSION['member_id'] = $member['id'];
                $_SESSION['email'] = $member['email'];
                $_SESSION['name'] = $member['first_name'] . ' ' . $member['last_name'];
                $_SESSION['membership_type'] = $member['membership_type'];

                // Update last login
                $update = $conn->prepare("UPDATE club_members SET last_login = NOW() WHERE id = :id");
                $update->execute([':id' => $member['id']]);

                header("Location: member_dashboard.php");
                exit();
            } else {
                $login_error = 'Invalid credentials.';
            }
        }
    } catch (PDOException $e) {
        error_log("Login error: " . $e->getMessage());
        $login_error = "Internal server error.";
    }
}
?>

<!-- Basic Login Form -->
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-header text-center">
                    <h4>User Login</h4>
                </div>
                <div class="card-body">
                    <?php if ($login_error): ?>
                        <div class="alert alert-danger"><?php echo $login_error; ?></div>
                    <?php endif; ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username or Email</label>
                            <input type="text" name="username" id="username" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" name="password" id="password" class="form-control" required>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Log In</button>
                        </div>
                    </form>
                </div>
                <div class="card-footer text-muted text-center">
                    &copy; <?php echo date("Y"); ?> Club System
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
