<?php
// admin_navbar.php - Navigation bar for admin pages

// Check if user is logged in and is an admin
if (!isset($_SESSION['username']) ){
    header("Location: login.php");
    exit();
}
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand" href="club_admin.php">
            <i class="fas fa-users me-2"></i>Club Admin
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="adminNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="club_admin.php">
                        <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="club_members.php">
                        <i class="fas fa-users me-1"></i>Members
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="approve_members.php">
                        <i class="fas fa-user-check me-1"></i>Approve Members
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="club_events.php">
                        <i class="fas fa-calendar-alt me-1"></i>Events
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="club_settings.php">
                        <i class="fas fa-cog me-1"></i>Settings
                    </a>
                </li>
            </ul>
            
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i>
                        <?php echo htmlspecialchars($_SESSION['username']); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="profile.php">
                            <i class="fas fa-user me-1"></i>Profile
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form action="logout.php" method="post" class="dropdown-item">
                                <button type="submit" class="btn btn-link text-decoration-none p-0">
                                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                                </button>
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Include Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>

<style>
    .navbar {
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .dropdown-menu {
        border: none;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .nav-link {
        padding: 0.5rem 1rem;
    }
    .navbar-brand {
        font-weight: 600;
    }
    .dropdown-item {
        padding: 0.5rem 1.5rem;
    }
    .dropdown-item:active {
        background-color: #f8f9fa;
        color: #212529;
    }
</style>