<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['member_id'])) {
    header('Location: login.php');
    exit;
}

// Database configuration
$db_host = 'localhost';
$db_name = 'keynan';
$db_user = 'root';
$db_pass = '';

// Connect to database
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get member data
$stmt = $pdo->prepare("SELECT * FROM club_members WHERE id = ?");
$stmt->execute([$_SESSION['member_id']]);
$member = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$member) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$errors = [];
$success = false;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validate current password
    if (empty($current_password)) {
        $errors[] = "Current password is required";
    } elseif (!password_verify($current_password, $member['password'])) {
        $errors[] = "Current password is incorrect";
    }
    
    // Validate new password
    if (empty($new_password)) {
        $errors[] = "New password is required";
    } elseif (strlen($new_password) < 8) {
        $errors[] = "New password must be at least 8 characters long";
    }
    
    // Validate password confirmation
    if ($new_password !== $confirm_password) {
        $errors[] = "New passwords do not match";
    }
    
    // Update password if no errors
    if (empty($errors)) {
        try {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE club_members SET password = ? WHERE id = ?");
            $stmt->execute([$hashed_password, $_SESSION['member_id']]);
            
            $success = true;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #f8f9fc;
            --accent-color: #2e59d9;
            --text-color: #5a5c69;
            --light-gray: #dddfeb;
            --dark-gray: #858796;
            --danger-color: #e74a3b;
            --success-color: #1cc88a;
        }
        
        body { 
            font-family: 'Nunito', Arial, sans-serif; 
            margin: 0; 
            padding: 0; 
            background-color: var(--secondary-color);
            color: var(--text-color);
        }
        
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Side Navigation (same as dashboard) */
        .sidenav {
            width: 250px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            transition: all 0.3s;
            z-index: 10;
        }
        
        .sidenav-header {
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .sidenav-header img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
            border: 3px solid var(--light-gray);
        }
        
        .sidenav-menu {
            padding: 1rem 0;
        }
        
        .nav-title {
            padding: 0 1.5rem;
            margin: 1.5rem 0 1rem;
            font-size: 0.75rem;
            font-weight: 800;
            text-transform: uppercase;
            color: var(--dark-gray);
            letter-spacing: 0.05em;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: var(--primary-color);
            background-color: var(--secondary-color);
        }
        
        .nav-link.active {
            color: var(--primary-color);
            font-weight: 700;
            border-left: 4px solid var(--primary-color);
        }
        
        .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            overflow-x: hidden;
        }
        
        .topbar {
            height: 70px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }
        
        .topbar h1 {
            font-size: 1.5rem;
            margin: 0;
            color: var(--primary-color);
        }
        
        .user-menu {
            display: flex;
            align-items: center;
        }
        
        .user-menu img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .logout-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background: var(--accent-color);
        }
        
        .container-fluid {
            padding: 2rem;
        }
        
        /* Form Styles */
        .password-form {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            max-width: 600px;
            margin: 0 auto;
        }
        
        .form-title {
            color: var(--primary-color);
            margin-top: 0;
            border-bottom: 1px solid var(--light-gray);
            padding-bottom: 10px;
            display: flex;
            align-items: center;
        }
        
        .form-title i {
            margin-right: 10px;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid var(--light-gray);
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        
        .btn {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background-color: var(--accent-color);
        }
        
        .btn-secondary {
            background-color: var(--dark-gray);
        }
        
        .btn-secondary:hover {
            background-color: #6c757d;
        }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .error-list {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        
        .error-list li {
            color: var(--danger-color);
            margin-bottom: 0.5rem;
        }
        
        .password-strength {
            margin-top: 0.5rem;
            height: 5px;
            background-color: var(--light-gray);
            border-radius: 2.5px;
            overflow: hidden;
        }
        
        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: width 0.3s, background-color 0.3s;
        }
        
        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }
            
            .sidenav {
                width: 100%;
                height: auto;
            }
            
            .password-form {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Side Navigation -->
        <div class="sidenav">
            <div class="sidenav-header">
                <img src="<?php echo htmlspecialchars($member['profile_pic'] ?: 'default-profile.jpg'); ?>" alt="Profile Picture">
                <h3><?php echo htmlspecialchars($member['first_name']); ?></h3>
                <p><?php echo ucfirst($member['membership_type']); ?> Member</p>
            </div>
            
            <div class="sidenav-menu">
                <div class="nav-title">Navigation</div>
                
                <div class="nav-item">
                    <a href="member_dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="club_calendar.php" class="nav-link">
                        <i class="fas fa-calendar-alt"></i>
                        <span>Events Calendar</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="resources.php" class="nav-link">
                        <i class="fas fa-book"></i>
                        <span>Member Resources</span>
                    </a>
                </div>
                
                <div class="nav-title">Account</div>
                
                <div class="nav-item">
                    <a href="edit_member_profile.php" class="nav-link">
                        <i class="fas fa-user-edit"></i>
                        <span>Edit Profile</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="change_password.php" class="nav-link active">
                        <i class="fas fa-key"></i>
                        <span>Change Password</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="membership_upgrade.php" class="nav-link">
                        <i class="fas fa-star"></i>
                        <span>Upgrade Membership</span>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="topbar">
                <h1>Change Password</h1>
                <div class="user-menu">
                    <img src="<?php echo htmlspecialchars($member['profile_pic'] ?: 'default-profile.jpg'); ?>" alt="Profile Picture">
                    <form action="logout.php" method="post">
                        <button type="submit" class="logout-btn">Logout</button>
                    </form>
                </div>
            </div>
            
            <div class="container-fluid">
                <div class="password-form">
                    <h2 class="form-title"><i class="fas fa-key"></i> Change Your Password</h2>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            Your password has been changed successfully!
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <ul class="error-list">
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="form-group">
                            <label for="current_password" class="form-label">Current Password</label>
                            <input type="password" id="current_password" name="current_password" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" id="new_password" name="new_password" class="form-control" required>
                            <div class="password-strength">
                                <div class="password-strength-bar" id="passwordStrengthBar"></div>
                            </div>
                            <small class="text-muted">Minimum 8 characters</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn">Change Password</button>
                            <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Password strength indicator
        document.getElementById('new_password').addEventListener('input', function(e) {
            const password = e.target.value;
            const strengthBar = document.getElementById('passwordStrengthBar');
            let strength = 0;
            
            // Length check
            if (password.length > 7) strength += 1;
            if (password.length > 11) strength += 1;
            
            // Character variety checks
            if (password.match(/[a-z]/)) strength += 1;
            if (password.match(/[A-Z]/)) strength += 1;
            if (password.match(/[0-9]/)) strength += 1;
            if (password.match(/[^a-zA-Z0-9]/)) strength += 1;
            
            // Update strength bar
            let width = 0;
            let color = '#e74a3b'; // red
            
            if (strength > 4) {
                width = 100;
                color = '#1cc88a'; // green
            } else if (strength > 2) {
                width = 66;
                color = '#f6c23e'; // yellow
            } else if (strength > 0) {
                width = 33;
            }
            
            strengthBar.style.width = width + '%';
            strengthBar.style.backgroundColor = color;
        });
    </script>
</body>
</html>