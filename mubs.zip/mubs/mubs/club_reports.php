<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'club_admin') {
    header("Location: login.php");
    exit();
}
include 'TCPDF/tcpdf.php';
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'keynan');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get club information
$username = $_SESSION['username'];
$club_name = "Your Club";
$result = $conn->query("SELECT id, club_name FROM clubs WHERE admin_username = '$username'");
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $club_name = $row['club_name'];
    $club_id = $row['id'];
}
$result->free();

// Handle report generation requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $report_type = $_POST['report_type'] ?? '';
    $format = $_POST['format'] ?? '';
    
    // Validate inputs
    if (in_array($report_type, ['members', 'events', 'finances', 'activities'])) {
        // Generate the requested report
        switch ($report_type) {
            case 'members':
                $result = $conn->query("SELECT * FROM club_members WHERE club_id = $club_id");
                $data = [];
                while ($row = $result->fetch_assoc()) {
                    $data[] = $row;
                }
                $filename = "{$club_name}_Members_Report_" . date('Y-m-d');
                $headers = ['ID', 'Name', 'Email', 'Join Date', 'Status'];
                break;
                
            case 'events':
                $result = $conn->query("SELECT * FROM club_events WHERE club_id = $club_id ORDER BY event_date DESC");
                $data = [];
                while ($row = $result->fetch_assoc()) {
                    $data[] = $row;
                }
                $filename = "{$club_name}_Events_Report_" . date('Y-m-d');
                $headers = ['ID', 'Event Name', 'Date', 'Location', 'Description'];
                break;
                
            case 'finances':
                $result = $conn->query("SELECT * FROM club_finances WHERE club_id = $club_id ORDER BY transaction_date DESC");
                $data = [];
                while ($row = $result->fetch_assoc()) {
                    $data[] = $row;
                }
                $filename = "{$club_name}_Financial_Report_" . date('Y-m-d');
                $headers = ['ID', 'Transaction Date', 'Description', 'Amount', 'Type'];
                break;
                
            case 'activities':
                $result = $conn->query("SELECT * FROM club_activities WHERE club_id = $club_id ORDER BY activity_date DESC");
                $data = [];
                while ($row = $result->fetch_assoc()) {
                    $data[] = $row;
                }
                $filename = "{$club_name}_Activities_Report_" . date('Y-m-d');
                $headers = ['ID', 'Activity Name', 'Date', 'Participants', 'Description'];
                break;
        }
        
        // Generate the file based on format
        if ($format === 'pdf') {
            require_once('tcpdf/tcpdf.php');
            
            // Create new PDF document
            $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
            
            // Set document information
            $pdf->SetCreator(PDF_CREATOR);
            $pdf->SetAuthor($club_name);
            $pdf->SetTitle($filename);
            
            // Add a page
            $pdf->AddPage();
            
            // Set font
            $pdf->SetFont('helvetica', 'B', 16);
            $pdf->Cell(0, 10, str_replace('_', ' ', $filename), 0, 1, 'C');
            $pdf->SetFont('helvetica', '', 10);
            $pdf->Ln(5);
            
            // Create table header
            $pdf->SetFillColor(220, 220, 220);
            $pdf->SetTextColor(0);
            $pdf->SetDrawColor(0, 0, 0);
            $pdf->SetLineWidth(0.1);
            $pdf->SetFont('', 'B');
            
            // Column widths
            $w = array_fill(0, count($headers), 40);
            
            // Header
            for($i = 0; $i < count($headers); $i++) {
                $pdf->Cell($w[$i], 7, $headers[$i], 1, 0, 'C', 1);
            }
            $pdf->Ln();
            
            // Data
            $pdf->SetFont('');
            foreach($data as $row) {
                $i = 0;
                foreach($row as $value) {
                    $pdf->Cell($w[$i], 6, $value, 'LR', 0, 'L');
                    $i++;
                }
                $pdf->Ln();
            }
            
            // Closing line
            $pdf->Cell(array_sum($w), 0, '', 'T');
            
            // Output PDF
            $pdf->Output("$filename.pdf", 'D');
            exit();
            
        } elseif ($format === 'excel') {
            header("Content-Type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename=\"$filename.xls\"");
            
            echo "<table border='1'>";
            echo "<tr>";
            foreach ($headers as $header) {
                echo "<th>" . htmlspecialchars($header) . "</th>";
            }
            echo "</tr>";
            
            foreach ($data as $row) {
                echo "<tr>";
                foreach ($row as $value) {
                    echo "<td>" . htmlspecialchars($value) . "</td>";
                }
                echo "</tr>";
            }
            
            echo "</table>";
            exit();
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Reports - <?php echo htmlspecialchars($club_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .report-card {
            transition: transform 0.2s;
        }
        .report-card:hover {
            transform: translateY(-5px);
        }
        main {
            padding-top: 20px;
        }
        .club-header {
            background-color: #6c757d;
            color: white;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-none d-md-block sidebar">
            <div class="sidebar-sticky pt-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Club Admin</h4>
                    <div class="text-white small"><?php echo htmlspecialchars($club_name); ?></div>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="club_admin.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_members.php">
                            <i class="fas fa-users me-2"></i>Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_events.php">
                            <i class="fas fa-calendar-alt me-2"></i>Events
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_finances.php">
                            <i class="fas fa-money-bill-wave me-2"></i>Finances
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_settings.php">
                            <i class="fas fa-cog me-2"></i>Club Settings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="club_reports.php">
                            <i class="fas fa-chart-bar me-2"></i>Reports
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Club Reports</h1>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['username']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
                        <li><a class="dropdown-item" href="club_profile.php"><i class="fas fa-user me-1"></i> Profile</a></li>
                        <li><a class="dropdown-item" href="club_settings.php"><i class="fas fa-cog me-1"></i> Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a></li>
                    </ul>
                </div>
            </div>

            <!-- Club Header -->
            <div class="club-header">
                <h3><i class="fas fa-chart-bar me-2"></i><?php echo htmlspecialchars($club_name); ?> Reports</h3>
                <p class="mb-0">Generate and download reports for your club.</p>
            </div>

            <!-- Report Cards -->
            <div class="row">
                <div class="col-md-6">
                    <div class="card report-card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-users me-2"></i>Members Report</h5>
                            <p class="card-text">Download a complete list of all club members with their details.</p>
                            <form method="post" class="d-flex gap-2">
                                <input type="hidden" name="report_type" value="members">
                                <button type="submit" name="format" value="excel" class="btn btn-success">
                                    <i class="fas fa-file-excel me-1"></i> Excel
                                </button>
                                <button type="submit" name="format" value="pdf" class="btn btn-danger">
                                    <i class="fas fa-file-pdf me-1"></i> PDF
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card report-card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-calendar-alt me-2"></i>Events Report</h5>
                            <p class="card-text">Download a list of all club events, past and upcoming.</p>
                            <form method="post" class="d-flex gap-2">
                                <input type="hidden" name="report_type" value="events">
                                <button type="submit" name="format" value="excel" class="btn btn-success">
                                    <i class="fas fa-file-excel me-1"></i> Excel
                                </button>
                                <button type="submit" name="format" value="pdf" class="btn btn-danger">
                                    <i class="fas fa-file-pdf me-1"></i> PDF
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card report-card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-money-bill-wave me-2"></i>Financial Report</h5>
                            <p class="card-text">Download financial transactions and balance information.</p>
                            <form method="post" class="d-flex gap-2">
                                <input type="hidden" name="report_type" value="finances">
                                <button type="submit" name="format" value="excel" class="btn btn-success">
                                    <i class="fas fa-file-excel me-1"></i> Excel
                                </button>
                                <button type="submit" name="format" value="pdf" class="btn btn-danger">
                                    <i class="fas fa-file-pdf me-1"></i> PDF
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card report-card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-history me-2"></i>Activities Report</h5>
                            <p class="card-text">Download a log of all club activities and participation.</p>
                            <form method="post" class="d-flex gap-2">
                                <input type="hidden" name="report_type" value="activities">
                                <button type="submit" name="format" value="excel" class="btn btn-success">
                                    <i class="fas fa-file-excel me-1"></i> Excel
                                </button>
                                <button type="submit" name="format" value="pdf" class="btn btn-danger">
                                    <i class="fas fa-file-pdf me-1"></i> PDF
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Custom Report Section -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-cogs me-2"></i>Custom Report</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="report_type" class="form-label">Report Type</label>
                                <select class="form-select" id="report_type" name="report_type" required>
                                    <option value="">Select a report type</option>
                                    <option value="members">Members Report</option>
                                    <option value="events">Events Report</option>
                                    <option value="finances">Financial Report</option>
                                    <option value="activities">Activities Report</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="format" class="form-label">Format</label>
                                <select class="form-select" id="format" name="format" required>
                                    <option value="">Select a format</option>
                                    <option value="excel">Excel (.xls)</option>
                                    <option value="pdf">PDF (.pdf)</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="start_date" class="form-label">Start Date (optional)</label>
                                <input type="date" class="form-control" id="start_date" name="start_date">
                            </div>
                            <div class="col-md-6">
                                <label for="end_date" class="form-label">End Date (optional)</label>
                                <input type="date" class="form-control" id="end_date" name="end_date">
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-download me-1"></i> Generate Report
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function() {
        // Set today's date as default end date
        $('#end_date').val(new Date().toISOString().split('T')[0]);
    });
</script>
</body>
</html>