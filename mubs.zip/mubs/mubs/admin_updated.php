<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'keynan');

require_once 'db.php';
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get comprehensive stats for dashboard
$user_count = 0;
$active_users = 0;
$club_count = 0;
$event_count = 0;
$sponsor_count = 0;
$budget_total = 0;
$recent_logs = array();
$new_users = array();
$system_stats = array();
$user_roles = array();
$recent_errors = array();

// Total users count
$result = $conn->query("SELECT COUNT(*) AS count FROM users");
if ($result) {
    $row = $result->fetch_assoc();
    $user_count = $row['count'];
    $result->free();
}

// Active users count
$result = $conn->query("SELECT COUNT(*) AS count FROM users WHERE last_login > DATE_SUB(NOW(), INTERVAL 30 DAY)");
if ($result) {
    $row = $result->fetch_assoc();
    $active_users = $row['count'];
    $result->free();
}

// Clubs count
$result = $conn->query("SELECT COUNT(*) AS count FROM clubs WHERE status = 'active'");
if ($result) {
    $row = $result->fetch_assoc();
    $club_count = $row['count'];
    $result->free();
}

// Events count
$result = $conn->query("SELECT COUNT(*) AS count FROM events WHERE event_date >= CURDATE()");
if ($result) {
    $row = $result->fetch_assoc();
    $event_count = $row['count'];
    $result->free();
}

// Sponsors count
$result = $conn->query("SELECT COUNT(*) AS count FROM sponsors WHERE status = 'active'");
if ($result) {
    $row = $result->fetch_assoc();
    $sponsor_count = $row['count'];
    $result->free();
}

// Total budget
$result = $conn->query("SELECT SUM(total_budget) AS total FROM club_budgets WHERE status = 'approved'");
if ($result) {
    $row = $result->fetch_assoc();
    $budget_total = $row['total'] ?? 0;
    $result->free();
}

// Recent activity logs
$result = $conn->query("SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 5");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $recent_logs[] = $row;
    }
    $result->free();
}

// New users (last 7 days)
$result = $conn->query("SELECT username, email, created_at FROM users WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY) ORDER BY created_at DESC LIMIT 5");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $new_users[] = $row;
    }
    $result->free();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Club Management System</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
            padding: 12px 15px;
            border-radius: 5px;
            margin-bottom: 5px;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        .sidebar .nav-link i {
            width: 20px;
            margin-right: 10px;
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border: none;
            border-radius: 10px;
        }
        .stat-card {
            text-align: center;
            padding: 25px;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card .stat-value {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .chart-container {
            position: relative;
            height: 300px;
            margin-bottom: 20px;
        }
        .badge-pill {
            padding: 0.5em 0.8em;
        }
        .progress {
            height: 10px;
            border-radius: 5px;
        }
        .system-health {
            font-weight: bold;
        }
        .health-excellent { color: #28a745; }
        .health-good { color: #17a2b8; }
        .health-warning { color: #ffc107; }
        .health-critical { color: #dc3545; }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-none d-md-block sidebar">
            <div class="sidebar-sticky pt-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Admin Panel</h4>
                    <small class="text-muted">Club Management System</small>
                </div>
                <ul class="nav flex-column">
                    <!-- Dashboard -->
                    <li class="nav-item">
                        <a class="nav-link active" href="admin.php">
                            <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                        </a>
                    </li>
                    
                    <!-- Manage Clubs -->
                    <li class="nav-item">
                        <a class="nav-link" href="manage_clubs.php">
                            <i class="fas fa-building mr-2"></i>Manage Clubs
                            <span class="badge badge-pill badge-light ml-auto"><?php echo $club_count; ?></span>
                        </a>
                    </li>
                    
                    <!-- Manage Users -->
                    <li class="nav-item">
                        <a class="nav-link" href="manage_users.php">
                            <i class="fas fa-users-cog mr-2"></i>Manage Users
                            <span class="badge badge-pill badge-light ml-auto"><?php echo $user_count; ?></span>
                        </a>
                    </li>
                    
                    <!-- Manage Sponsors -->
                    <li class="nav-item">
                        <a class="nav-link" href="manage_sponsors.php">
                            <i class="fas fa-handshake mr-2"></i>Manage Sponsors
                            <span class="badge badge-pill badge-light ml-auto"><?php echo $sponsor_count; ?></span>
                        </a>
                    </li>
                    
                    <!-- Manage Events -->
                    <li class="nav-item">
                        <a class="nav-link" href="manage_events.php">
                            <i class="fas fa-calendar-alt mr-2"></i>Manage Events
                            <span class="badge badge-pill badge-light ml-auto"><?php echo $event_count; ?></span>
                        </a>
                    </li>
                    
                    <!-- Budget Oversight -->
                    <li class="nav-item">
                        <a class="nav-link" href="budget_oversight.php">
                            <i class="fas fa-money-bill-wave mr-2"></i>Budget Oversight
                            <span class="badge badge-pill badge-light ml-auto">$<?php echo number_format($budget_total); ?></span>
                        </a>
                    </li>
                    
                    <!-- Reports -->
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-line mr-2"></i>Reports
                        </a>
                    </li>
                    
                    <!-- Activity Logs -->
                    <li class="nav-item">
                        <a class="nav-link" href="activity_logs.php">
                            <i class="fas fa-history mr-2"></i>Activity Logs
                        </a>
                    </li>
                    
                    <!-- Settings -->
                    <li class="nav-item">
                        <a class="nav-link" href="settings.php">
                            <i class="fas fa-cogs mr-2"></i>Settings
                        </a>
                    </li>
                    
                    <!-- Logout -->
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main role="main" class="col-md-10 ml-sm-auto px-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Dashboard</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="dropdown">
                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle mr-1"></i><?php echo htmlspecialchars($_SESSION['username']); ?>
                        </button>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="profile.php"><i class="fas fa-user mr-1"></i> Profile</a>
                            <a class="dropdown-item" href="settings.php"><i class="fas fa-cog mr-1"></i> Settings</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt mr-1"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="row">
                <div class="col-md-3">
                    <div class="card stat-card bg-primary text-white">
                        <div class="card-body">
                            <h5 class="card-title">Total Users</h5>
                            <div class="stat-value"><?php echo $user_count; ?></div>
                            <p class="mb-0"><i class="fas fa-users"></i> System users</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-success text-white">
                        <div class="card-body">
                            <h5 class="card-title">Active Users</h5>
                            <div class="stat-value"><?php echo $active_users; ?></div>
                            <p class="mb-0"><i class="fas fa-user-check"></i> Last 30 days</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-info text-white">
                        <div class="card-body">
                            <h5 class="card-title">Active Clubs</h5>
                            <div class="stat-value"><?php echo $club_count; ?></div>
                            <p class="mb-0"><i class="fas fa-building"></i> Registered clubs</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-warning text-white">
                        <div class="card-body">
                            <h5 class="card-title">Upcoming Events</h5>
                            <div class="stat-value"><?php echo $event_count; ?></div>
                            <p class="mb-0"><i class="fas fa-calendar"></i> Future events</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-3">
                    <div class="card stat-card bg-danger text-white">
                        <div class="card-body">
                            <h5 class="card-title">Active Sponsors</h5>
                            <div class="stat-value"><?php echo $sponsor_count; ?></div>
                            <p class="mb-0"><i class="fas fa-handshake"></i> Partnerships</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-dark text-white">
                        <div class="card-body">
                            <h5 class="card-title">Total Budget</h5>
                            <div class="stat-value">$<?php echo number_format($budget_total); ?></div>
                            <p class="mb-0"><i class="fas fa-money-bill"></i> Approved budgets</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-bolt mr-2"></i>Quick Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-2 mb-3">
                                    <a href="add_club.php" class="btn btn-primary btn-block">
                                        <i class="fas fa-plus"></i><br>Add Club
                                    </a>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <a href="add_user.php" class="btn btn-success btn-block">
                                        <i class="fas fa-user-plus"></i><br>Add User
                                    </a>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <a href="add_sponsor.php" class="btn btn-info btn-block">
                                        <i class="fas fa-handshake"></i><br>Add Sponsor
                                    </a>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <a href="create_event.php" class="btn btn-warning btn-block">
                                        <i class="fas fa-calendar-plus"></i><br>Create Event
                                    </a>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <a href="create_budget.php" class="btn btn-danger btn-block">
                                        <i class="fas fa-dollar-sign"></i><br>Create Budget
                                    </a>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <a href="generate_report.php" class="btn btn-dark btn-block">
                                        <i class="fas fa-file-alt"></i><br>Generate Report
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
</body>
</html>
