<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['member_id'])) {
    header('Location: login.php');
    exit;
}

// Database configuration
$db_host = 'localhost';
$db_name = 'keynan';
$db_user = 'root';
$db_pass = '';

// Connect to database
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get member data
$stmt = $pdo->prepare("SELECT * FROM club_members WHERE id = ?");
$stmt->execute([$_SESSION['member_id']]);
$member = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$member) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$errors = [];
$success = false;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    
    // Basic validation
    if (empty($first_name)) {
        $errors[] = "First name is required";
    }
    
    if (empty($last_name)) {
        $errors[] = "Last name is required";
    }
    
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    // Check if email is already taken by another user
    $stmt = $pdo->prepare("SELECT id FROM club_members WHERE email = ? AND id != ?");
    $stmt->execute([$email, $_SESSION['member_id']]);
    if ($stmt->fetch()) {
        $errors[] = "Email is already registered";
    }
    
    // Handle profile picture upload
    $profile_pic = $member['profile_pic'];
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['profile_pic']['type'];
        
        if (in_array($file_type, $allowed_types)) {
            $upload_dir = 'uploads/profile_pics/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_ext = pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION);
            $new_filename = 'member_' . $_SESSION['member_id'] . '_' . time() . '.' . $file_ext;
            $destination = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['profile_pic']['tmp_name'], $destination)) {
                // Delete old profile picture if it exists and isn't the default
                if ($profile_pic && $profile_pic !== 'default-profile.jpg' && file_exists($profile_pic)) {
                    unlink($profile_pic);
                }
                $profile_pic = $destination;
            } else {
                $errors[] = "Failed to upload profile picture";
            }
        } else {
            $errors[] = "Only JPG, PNG, and GIF images are allowed";
        }
    }
    
    // Update profile if no errors
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("UPDATE club_members SET 
                first_name = ?, 
                last_name = ?, 
                email = ?, 
                phone = ?, 
                address = ?, 
                profile_pic = ? 
                WHERE id = ?");
            
            $stmt->execute([ 
                $first_name,
                $last_name,
                $email,
                $phone,
                $address,
                $profile_pic,
                $_SESSION['member_id']
            ]);
            
            $success = true;
            // Refresh member data
            $stmt = $pdo->prepare("SELECT * FROM club_members WHERE id = ?");
            $stmt->execute([$_SESSION['member_id']]);
            $member = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #f8f9fc;
            --accent-color: #2e59d9;
            --text-color: #5a5c69;
            --light-gray: #dddfeb;
            --dark-gray: #858796;
            --danger-color: #e74a3b;
            --success-color: #1cc88a;
        }
        
        body { 
            font-family: 'Nunito', Arial, sans-serif; 
            margin: 0; 
            padding: 0; 
            background-color: var(--secondary-color);
            color: var(--text-color);
        }
        
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Side Navigation (same as dashboard) */
        .sidenav {
            width: 250px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            transition: all 0.3s;
            z-index: 10;
        }
        
        .sidenav-header {
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .sidenav-header img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
            border: 3px solid var(--light-gray);
        }
        
        .sidenav-menu {
            padding: 1rem 0;
        }
        
        .nav-title {
            padding: 0 1.5rem;
            margin: 1.5rem 0 1rem;
            font-size: 0.75rem;
            font-weight: 800;
            text-transform: uppercase;
            color: var(--dark-gray);
            letter-spacing: 0.05em;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: var(--primary-color);
            background-color: var(--secondary-color);
        }
        
        .nav-link.active {
            color: var(--primary-color);
            font-weight: 700;
            border-left: 4px solid var(--primary-color);
        }
        
        .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            overflow-x: hidden;
        }
        
        .topbar {
            height: 70px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }
        
        .topbar h1 {
            font-size: 1.5rem;
            margin: 0;
            color: var(--primary-color);
        }
        
        .user-menu {
            display: flex;
            align-items: center;
        }
        
        .user-menu img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .logout-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background: var(--accent-color);
        }
        
        .container-fluid {
            padding: 2rem;
        }
        
        /* Form Styles */
        .profile-form {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        }
        
        .form-title {
            color: var(--primary-color);
            margin-top: 0;
            border-bottom: 1px solid var(--light-gray);
            padding-bottom: 10px;
            display: flex;
            align-items: center;
        }
        
        .form-title i {
            margin-right: 10px;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid var(--light-gray);
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        
        .profile-pic-container {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .profile-pic-preview {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 20px;
            border: 3px solid var(--light-gray);
        }
        
        .btn {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background-color: var(--accent-color);
        }
        
        .btn-secondary {
            background-color: var(--dark-gray);
        }
        
        .btn-secondary:hover {
            background-color: #6c757d;
        }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .error-list {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        
        .error-list li {
            color: var(--danger-color);
            margin-bottom: 0.5rem;
        }
        
        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }
            
            .sidenav {
                width: 100%;
                height: auto;
            }
            
            .profile-pic-container {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .profile-pic-preview {
                margin-bottom: 15px;
                margin-right: 0;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Side Navigation -->
        <div class="sidenav">
            <div class="sidenav-header">
                <img src="<?php echo htmlspecialchars($member['profile_pic'] ?: 'default-profile.jpg'); ?>" alt="Profile Picture">
                <h3><?php echo htmlspecialchars($member['first_name']); ?></h3>
                <p><?php echo ucfirst($member['membership_type']); ?> Member</p>
            </div>
            
            <div class="sidenav-menu">
                <div class="nav-title">Navigation</div>
                
                <div class="nav-item">
                    <a href="member_dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="club_calendar.php" class="nav-link">
                        <i class="fas fa-calendar-alt"></i>
                        <span>Events Calendar</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="resources.php" class="nav-link">
                        <i class="fas fa-book"></i>
                        <span>Member Resources</span>
                    </a>
                </div>
                
                <div class="nav-title">Account</div>
                
                <div class="nav-item">
                    <a href="edit_profile.php" class="nav-link active">
                        <i class="fas fa-user-edit"></i>
                        <span>Edit Profile</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="change_password.php" class="nav-link">
                        <i class="fas fa-key"></i>
                        <span>Change Password</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="membership_upgrade.php" class="nav-link">
                        <i class="fas fa-star"></i>
                        <span>Upgrade Membership</span>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="topbar">
                <h1>Edit Profile</h1>
                <div class="user-menu">
                    <img src="<?php echo htmlspecialchars($member['profile_pic'] ?: 'default-profile.jpg'); ?>" alt="Profile Picture">
                    <form action="logout.php" method="post">
                        <button type="submit" class="logout-btn">Logout</button>
                    </form>
                </div>
            </div>
            
            <div class="container-fluid">
                <div class="profile-form">
                    <h2 class="form-title"><i class="fas fa-user-edit"></i> Profile Information</h2>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            Your profile has been updated successfully!
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <ul class="error-list">
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" enctype="multipart/form-data">
                        <div class="profile-pic-container">
                            <img src="<?php echo htmlspecialchars($member['profile_pic'] ?: 'default-profile.jpg'); ?>" alt="Current Profile Picture" class="profile-pic-preview" id="profilePicPreview">
                            <div>
                                <label for="profile_pic" class="form-label">Profile Picture</label>
                                <input type="file" id="profile_pic" name="profile_pic" accept="image/*" class="form-control" style="padding: 0.3rem;">
                                <small class="text-muted">Max size: 2MB (JPEG, PNG, GIF)</small>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="first_name" class="form-label">First Name</label>
                            <input type="text" id="first_name" name="first_name" class="form-control" value="<?php echo htmlspecialchars($member['first_name']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="last_name" class="form-label">Last Name</label>
                            <input type="text" id="last_name" name="last_name" class="form-control" value="<?php echo htmlspecialchars($member['last_name']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($member['email']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" id="phone" name="phone" class="form-control" value="<?php echo htmlspecialchars($member['phone'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="address" class="form-label">Address</label>
                            <textarea id="address" name="address" class="form-control" rows="3"><?php echo htmlspecialchars($member['address'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn">Update Profile</button>
                            <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Preview profile picture before upload
        document.getElementById('profile_pic').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('profilePicPreview').src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>