<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'club_admin') {
    header("Location: login.php");
    exit();
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'keynan');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get club information
$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT id, club_name FROM clubs WHERE admin_username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $club_id = $row['id'];
    $club_name = $row['club_name'];
} else {
    die("Error: Club not found for this admin.");
}
$stmt->close();

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_transaction'])) {
        // Add new financial transaction
        $amount = floatval($_POST['amount']);
        $description = trim($_POST['description']);
        $category = $_POST['category'];
        $transaction_date = $_POST['transaction_date'];
        $transaction_type = $_POST['transaction_type'];
        
        if (empty($description) || $amount <= 0) {
            $error_message = "Please provide a valid amount and description";
        } else {
            $stmt = $conn->prepare("INSERT INTO club_finances 
                                  (club_id, amount, description, category, transaction_date, transaction_type) 
                                  VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("idssss", $club_id, $amount, $description, $category, $transaction_date, $transaction_type);
            
            if ($stmt->execute()) {
                $success_message = "Transaction added successfully!";
            } else {
                $error_message = "Error adding transaction: " . $stmt->error;
            }
            $stmt->close();
        }
    } elseif (isset($_POST['delete_transaction'])) {
        // Delete a transaction
        $transaction_id = intval($_POST['transaction_id']);
        
        $stmt = $conn->prepare("DELETE FROM club_finances WHERE id = ? AND club_id = ?");
        $stmt->bind_param("ii", $transaction_id, $club_id);
        
        if ($stmt->execute()) {
            $success_message = "Transaction deleted successfully!";
        } else {
            $error_message = "Error deleting transaction: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Get financial summary
$summary_query = "SELECT 
    SUM(CASE WHEN transaction_type = 'income' THEN amount ELSE 0 END) as total_income,
    SUM(CASE WHEN transaction_type = 'expense' THEN amount ELSE 0 END) as total_expenses,
    SUM(CASE WHEN transaction_type = 'income' THEN amount ELSE -amount END) as balance
    FROM club_finances WHERE club_id = ?";
$stmt_summary = $conn->prepare($summary_query);
$stmt_summary->bind_param("i", $club_id);
$stmt_summary->execute();
$summary_result = $stmt_summary->get_result();
$summary = $summary_result->fetch_assoc();
$stmt_summary->close();

// Get recent transactions
$transactions_query = "SELECT * FROM club_finances 
                      WHERE club_id = ? 
                      ORDER BY transaction_date DESC, id DESC 
                      LIMIT 20";
$stmt_transactions = $conn->prepare($transactions_query);
$stmt_transactions->bind_param("i", $club_id);
$stmt_transactions->execute();
$transactions_result = $stmt_transactions->get_result();

// Get categories for dropdown
$categories_query = "SELECT DISTINCT category FROM club_finances WHERE club_id = ? ORDER BY category";
$stmt_categories = $conn->prepare($categories_query);
$stmt_categories->bind_param("i", $club_id);
$stmt_categories->execute();
$categories_result = $stmt_categories->get_result();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Finances - <?php echo htmlspecialchars($club_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .stat-card {
            text-align: center;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .income-card {
            background-color: #e8f5e9;
            border-left: 4px solid #2e7d32;
        }
        .expense-card {
            background-color: #ffebee;
            border-left: 4px solid #c62828;
        }
        .balance-card {
            background-color: #e3f2fd;
            border-left: 4px solid #1565c0;
        }
        .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
        }
        .income-text {
            color: #2e7d32;
        }
        .expense-text {
            color: #c62828;
        }
        .chart-container {
            position: relative;
            height: 300px;
            margin-bottom: 20px;
        }
        .transaction-income {
            border-left: 4px solid #2e7d32;
        }
        .transaction-expense {
            border-left: 4px solid #c62828;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-none d-md-block sidebar">
            <div class="sidebar-sticky pt-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Club Admin</h4>
                    <div class="text-white small"><?php echo htmlspecialchars($club_name); ?></div>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="club_admin.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_members.php">
                            <i class="fas fa-users me-2"></i>Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_events.php">
                            <i class="fas fa-calendar-alt me-2"></i>Events
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="club_finances.php">
                            <i class="fas fa-money-bill-wave me-2"></i>Finances
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_settings.php">
                            <i class="fas fa-cog me-2"></i>Settings
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="fas fa-money-bill-wave me-2"></i>Club Finances</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTransactionModal">
                        <i class="fas fa-plus me-1"></i>Add Transaction
                    </button>
                </div>
            </div>

            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i><?php echo $success_message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i><?php echo $error_message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Financial Summary Cards -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="stat-card income-card">
                        <h5>Total Income</h5>
                        <div class="stat-value income-text">$<?php echo number_format($summary['total_income'] ?? 0, 2); ?></div>
                        <small class="text-muted">All time</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card expense-card">
                        <h5>Total Expenses</h5>
                        <div class="stat-value expense-text">$<?php echo number_format($summary['total_expenses'] ?? 0, 2); ?></div>
                        <small class="text-muted">All time</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card balance-card">
                        <h5>Current Balance</h5>
                        <div class="stat-value">$<?php echo number_format($summary['balance'] ?? 0, 2); ?></div>
                        <small class="text-muted">Updated just now</small>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Income vs Expenses</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="incomeExpenseChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Spending by Category</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="categoryChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Transactions -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Recent Transactions</h5>
                </div>
                <div class="card-body">
                    <?php if ($transactions_result->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table id="transactionsTable" class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Description</th>
                                        <th>Category</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($transaction = $transactions_result->fetch_assoc()): ?>
                                    <tr class="<?php echo $transaction['transaction_type'] === 'income' ? 'transaction-income' : 'transaction-expense'; ?>">
                                        <td><?php echo date('M j, Y', strtotime($transaction['transaction_date'])); ?></td>
                                        <td><?php echo htmlspecialchars($transaction['description']); ?></td>
                                        <td><?php echo htmlspecialchars($transaction['category']); ?></td>
                                        <td>
                                            <span class="badge <?php echo $transaction['transaction_type'] === 'income' ? 'bg-success' : 'bg-danger'; ?>">
                                                <?php echo ucfirst($transaction['transaction_type']); ?>
                                            </span>
                                        </td>
                                        <td class="<?php echo $transaction['transaction_type'] === 'income' ? 'income-text' : 'expense-text'; ?>">
                                            <?php echo ($transaction['transaction_type'] === 'income' ? '+' : '-') . '$' . number_format($transaction['amount'], 2); ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteTransactionModal" 
                                                onclick="setDeleteTransaction(<?php echo $transaction['id']; ?>, '<?php echo htmlspecialchars($transaction['description']); ?>')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info text-center">
                            <i class="fas fa-money-bill-wave fa-3x mb-3 text-muted"></i>
                            <h5>No Transactions Found</h5>
                            <p>Your club doesn't have any financial transactions yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Add Transaction Modal -->
<div class="modal fade" id="addTransactionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Transaction</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Transaction Type</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="transaction_type" id="incomeType" value="income" checked>
                            <label class="form-check-label" for="incomeType">
                                Income
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="transaction_type" id="expenseType" value="expense">
                            <label class="form-check-label" for="expenseType">
                                Expense
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="amount" class="form-label">Amount</label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" class="form-control" id="amount" name="amount" min="0.01" step="0.01" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <input type="text" class="form-control" id="description" name="description" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="category" class="form-label">Category</label>
                        <select class="form-select" id="category" name="category">
                            <option value="Membership">Membership</option>
                            <option value="Event">Event</option>
                            <option value="Donation">Donation</option>
                            <option value="Equipment">Equipment</option>
                            <option value="Other">Other</option>
                            <?php while ($category = $categories_result->fetch_assoc()): ?>
                                <option value="<?php echo htmlspecialchars($category['category']); ?>"><?php echo htmlspecialchars($category['category']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="transaction_date" class="form-label">Date</label>
                        <input type="date" class="form-control" id="transaction_date" name="transaction_date" 
                               value="<?php echo date('Y-m-d'); ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_transaction" class="btn btn-primary">Add Transaction</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Transaction Modal -->
<div class="modal fade" id="deleteTransactionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Deletion</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this transaction?</p>
                <p class="text-muted" id="transactionDescription"></p>
                <p class="text-danger"><small>This action cannot be undone.</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="transaction_id" id="deleteTransactionId">
                    <button type="submit" name="delete_transaction" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js"></script>
<script>
$(document).ready(function() {
    // Initialize DataTable
    $('#transactionsTable').DataTable({
        "order": [[0, "desc"]],
        "pageLength": 10
    });
    
    // Set up delete transaction modal
    window.setDeleteTransaction = function(id, description) {
        $('#deleteTransactionId').val(id);
        $('#transactionDescription').text(description);
    };
    
    // Initialize charts
    const incomeExpenseCtx = document.getElementById('incomeExpenseChart').getContext('2d');
    const incomeExpenseChart = new Chart(incomeExpenseCtx, {
        type: 'bar',
        data: {
            labels: ['Last 7 Days', 'Last 30 Days', 'Last 90 Days', 'This Year'],
            datasets: [
                {
                    label: 'Income',
                    data: [1250, 3200, 8500, 15000],
                    backgroundColor: 'rgba(46, 125, 50, 0.7)'
                },
                {
                    label: 'Expenses',
                    data: [980, 2800, 7200, 12500],
                    backgroundColor: 'rgba(198, 40, 40, 0.7)'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    
    const categoryCtx = document.getElementById('categoryChart').getContext('2d');
    const categoryChart = new Chart(categoryCtx, {
        type: 'doughnut',
        data: {
            labels: ['Membership', 'Events', 'Equipment', 'Donations', 'Other'],
            datasets: [{
                data: [35, 25, 20, 15, 5],
                backgroundColor: [
                    'rgba(46, 125, 50, 0.7)',
                    'rgba(33, 150, 243, 0.7)',
                    'rgba(255, 152, 0, 0.7)',
                    'rgba(156, 39, 176, 0.7)',
                    'rgba(120, 144, 156, 0.7)'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right'
                }
            }
        }
    });
});
</script>
</body>
</html>