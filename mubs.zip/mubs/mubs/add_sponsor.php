<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'club_admin') {
    header("Location: login.php");
    exit();
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');     
define('DB_NAME', 'keynan');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$errors = [];
$success = false;
$club_id = 0;
$club_name = "Your Club";

// Get club information
$username = $_SESSION['username'];
$result = $conn->query("SELECT id, club_name FROM clubs WHERE admin_username = '$username'");
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $club_name = $row['club_name'];
    $club_id = $row['id'];
}
$result->free();

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $sponsor_name = trim($_POST['sponsor_name']);
    $contact_person = trim($_POST['contact_person']);
    $contact_email = trim($_POST['contact_email']);
    $contact_phone = trim($_POST['contact_phone']);
    $amount = trim($_POST['amount']);
    $sponsorship_date = trim($_POST['sponsorship_date']);
    $end_date = trim($_POST['end_date']);
    $agreement_details = trim($_POST['agreement_details']);
    $benefits = trim($_POST['benefits']);
    $notes = trim($_POST['notes']);

    // Validate required fields
    if (empty($sponsor_name)) {
        $errors['sponsor_name'] = "Sponsor name is required";
    }
    if (empty($contact_email)) {
        $errors['contact_email'] = "Contact email is required";
    } elseif (!filter_var($contact_email, FILTER_VALIDATE_EMAIL)) {
        $errors['contact_email'] = "Invalid email format";
    }
    if (empty($amount)) {
        $errors['amount'] = "Amount is required";
    } elseif (!is_numeric($amount)) {
        $errors['amount'] = "Amount must be a number";
    }
    if (empty($sponsorship_date)) {
        $errors['sponsorship_date'] = "Start date is required";
    }

    // If no errors, insert into database
    if (empty($errors)) {
        // Prepare SQL statement
        $stmt = $conn->prepare("INSERT INTO club_sponsors 
                               (club_id, sponsor_name, contact_person, contact_email, contact_phone, 
                                amount, sponsorship_date, end_date, agreement_details, benefits, notes) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        // Bind parameters
        $stmt->bind_param("issssdsssss", 
            $club_id,
            $sponsor_name,
            $contact_person,
            $contact_email,
            $contact_phone,
            $amount,
            $sponsorship_date,
            $end_date,
            $agreement_details,
            $benefits,
            $notes
        );

        // Execute statement
        if ($stmt->execute()) {
            $success = true;
            // Clear form fields if success
            $_POST = array();
        } else {
            $errors['database'] = "Error adding sponsor: " . $stmt->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Sponsor - <?php echo htmlspecialchars($club_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .club-header {
            background-color: #6c757d;
            color: white;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .is-invalid {
            border-color: #dc3545;
        }
        .invalid-feedback {
            display: block;
            color: #dc3545;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-none d-md-block sidebar">
            <div class="sidebar-sticky pt-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Club Admin</h4>
                    <div class="text-white small"><?php echo htmlspecialchars($club_name); ?></div>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="club_admin.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_members.php">
                            <i class="fas fa-users me-2"></i>Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_events.php">
                            <i class="fas fa-calendar-alt me-2"></i>Events
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_finances.php">
                            <i class="fas fa-money-bill-wave me-2"></i>Finances
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="club_sponsors.php">
                            <i class="fas fa-handshake me-2"></i>Sponsors
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_settings.php">
                            <i class="fas fa-cog me-2"></i>Club Settings
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Add New Sponsor</h1>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['username']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
                        <li><a class="dropdown-item" href="club_profile.php"><i class="fas fa-user me-1"></i> Profile</a></li>
                        <li><a class="dropdown-item" href="club_settings.php"><i class="fas fa-cog me-1"></i> Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a></li>
                    </ul>
                </div>
            </div>

            <!-- Club Header -->
            <div class="club-header">
                <h3><i class="fas fa-handshake me-2"></i><?php echo htmlspecialchars($club_name); ?></h3>
                <p class="mb-0">Add a new sponsor to your club's sponsorship program.</p>
            </div>

            <!-- Success Alert -->
            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i> Sponsor added successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- Error Alert -->
            <?php if (isset($errors['database'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $errors['database']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- Sponsor Form -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Sponsor Information</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="add_sponsor.php">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="sponsor_name" class="form-label">Sponsor Name *</label>
                                <input type="text" class="form-control <?php echo isset($errors['sponsor_name']) ? 'is-invalid' : ''; ?>" 
                                       id="sponsor_name" name="sponsor_name" 
                                       value="<?php echo htmlspecialchars($_POST['sponsor_name'] ?? ''); ?>" required>
                                <?php if (isset($errors['sponsor_name'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['sponsor_name']; ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-6">
                                <label for="contact_person" class="form-label">Contact Person</label>
                                <input type="text" class="form-control" id="contact_person" name="contact_person" 
                                       value="<?php echo htmlspecialchars($_POST['contact_person'] ?? ''); ?>">
                            </div>

                            <div class="col-md-6">
                                <label for="contact_email" class="form-label">Contact Email *</label>
                                <input type="email" class="form-control <?php echo isset($errors['contact_email']) ? 'is-invalid' : ''; ?>" 
                                       id="contact_email" name="contact_email" 
                                       value="<?php echo htmlspecialchars($_POST['contact_email'] ?? ''); ?>" required>
                                <?php if (isset($errors['contact_email'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['contact_email']; ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-6">
                                <label for="contact_phone" class="form-label">Contact Phone</label>
                                <input type="tel" class="form-control" id="contact_phone" name="contact_phone" 
                                       value="<?php echo htmlspecialchars($_POST['contact_phone'] ?? ''); ?>">
                            </div>

                            <div class="col-md-4">
                                <label for="amount" class="form-label">Sponsorship Amount *</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" step="0.01" class="form-control <?php echo isset($errors['amount']) ? 'is-invalid' : ''; ?>" 
                                           id="amount" name="amount" 
                                           value="<?php echo htmlspecialchars($_POST['amount'] ?? ''); ?>" required>
                                </div>
                                <?php if (isset($errors['amount'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['amount']; ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-4">
                                <label for="sponsorship_date" class="form-label">Start Date *</label>
                                <input type="date" class="form-control <?php echo isset($errors['sponsorship_date']) ? 'is-invalid' : ''; ?>" 
                                       id="sponsorship_date" name="sponsorship_date" 
                                       value="<?php echo htmlspecialchars($_POST['sponsorship_date'] ?? date('Y-m-d')); ?>" required>
                                <?php if (isset($errors['sponsorship_date'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['sponsorship_date']; ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-4">
                                <label for="end_date" class="form-label">End Date (optional)</label>
                                <input type="date" class="form-control" id="end_date" name="end_date" 
                                       value="<?php echo htmlspecialchars($_POST['end_date'] ?? ''); ?>">
                            </div>

                            <div class="col-12">
                                <label for="agreement_details" class="form-label">Agreement Details</label>
                                <textarea class="form-control" id="agreement_details" name="agreement_details" rows="3"><?php 
                                    echo htmlspecialchars($_POST['agreement_details'] ?? ''); ?></textarea>
                            </div>

                            <div class="col-12">
                                <label for="benefits" class="form-label">Benefits Provided</label>
                                <textarea class="form-control" id="benefits" name="benefits" rows="3"><?php 
                                    echo htmlspecialchars($_POST['benefits'] ?? ''); ?></textarea>
                            </div>

                            <div class="col-12">
                                <label for="notes" class="form-label">Additional Notes</label>
                                <textarea class="form-control" id="notes" name="notes" rows="2"><?php 
                                    echo htmlspecialchars($_POST['notes'] ?? ''); ?></textarea>
                            </div>

                            <div class="col-12 mt-4">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fas fa-save me-1"></i> Save Sponsor
                                </button>
                                <a href="club_sponsors.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-times me-1"></i> Cancel
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Set today's date as default for sponsorship date
    document.addEventListener('DOMContentLoaded', function() {
        if (!document.getElementById('sponsorship_date').value) {
            document.getElementById('sponsorship_date').valueAsDate = new Date();
        }
    });
</script>
</body>
</html>