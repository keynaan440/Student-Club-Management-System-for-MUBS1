<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['member_id'])) {
    header('Location: login.php');
    exit;
}

// Database configuration
$db_host = 'localhost';
$db_name = 'keynan';
$db_user = 'root';
$db_pass = '';

// Connect to database
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get member data
$stmt = $pdo->prepare("SELECT * FROM club_members WHERE id = ?");
$stmt->execute([$_SESSION['member_id']]);
$member = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$member) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Get events data
$events = [];
try {
    $stmt = $pdo->query("SELECT * FROM club_events WHERE event_date >= NOW() ORDER BY event_date ASC");
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Error fetching events: " . $e->getMessage();
}

// Update last login time
$pdo->prepare("UPDATE club_members SET last_login = NOW() WHERE id = ?")->execute([$_SESSION['member_id']]);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Events Calendar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #f8f9fc;
            --accent-color: #2e59d9;
            --text-color: #5a5c69;
            --light-gray: #dddfeb;
            --dark-gray: #858796;
        }
        
        body { 
            font-family: 'Nunito', Arial, sans-serif; 
            margin: 0; 
            padding: 0; 
            background-color: var(--secondary-color);
            color: var(--text-color);
        }
        
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Side Navigation (same as dashboard) */
        .sidenav {
            width: 250px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            transition: all 0.3s;
            z-index: 10;
        }
        
        .sidenav-header {
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .sidenav-header img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
            border: 3px solid var(--light-gray);
        }
        
        .sidenav-menu {
            padding: 1rem 0;
        }
        
        .nav-title {
            padding: 0 1.5rem;
            margin: 1.5rem 0 1rem;
            font-size: 0.75rem;
            font-weight: 800;
            text-transform: uppercase;
            color: var(--dark-gray);
            letter-spacing: 0.05em;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: var(--primary-color);
            background-color: var(--secondary-color);
        }
        
        .nav-link.active {
            color: var(--primary-color);
            font-weight: 700;
            border-left: 4px solid var(--primary-color);
        }
        
        .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            overflow-x: hidden;
        }
        
        .topbar {
            height: 70px;
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }
        
        .topbar h1 {
            font-size: 1.5rem;
            margin: 0;
            color: var(--primary-color);
        }
        
        .user-menu {
            display: flex;
            align-items: center;
        }
        
        .user-menu img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .logout-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background: var(--accent-color);
        }
        
        .container-fluid {
            padding: 2rem;
        }
        
        /* Calendar Styles */
        .calendar-container {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            margin-bottom: 2rem;
        }
        
        #calendar {
            margin-top: 20px;
        }
        
        .fc-toolbar-title {
            color: var(--primary-color);
            font-weight: 600;
        }
        
        .fc-button {
            background-color: var(--primary-color) !important;
            border-color: var(--primary-color) !important;
        }
        
        .fc-button:hover {
            background-color: var(--accent-color) !important;
            border-color: var(--accent-color) !important;
        }
        
        .fc-button-active {
            background-color: var(--accent-color) !important;
            border-color: var(--accent-color) !important;
        }
        
        /* Events List */
        .events-list {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        }
        
        .events-list h2 {
            color: var(--primary-color);
            margin-top: 0;
            border-bottom: 1px solid var(--light-gray);
            padding-bottom: 10px;
        }
        
        .event-card {
            border-left: 4px solid var(--primary-color);
            padding: 15px;
            margin-bottom: 15px;
            background-color: var(--secondary-color);
            border-radius: 4px;
        }
        
        .event-title {
            font-weight: 600;
            color: var(--primary-color);
            margin-top: 0;
        }
        
        .event-meta {
            display: flex;
            margin-bottom: 10px;
        }
        
        .event-date, .event-location {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }
        
        .event-date i, .event-location i {
            margin-right: 5px;
            color: var(--dark-gray);
        }
        
        .event-description {
            color: var(--text-color);
        }
        
        .no-events {
            text-align: center;
            padding: 20px;
            color: var(--dark-gray);
        }
        
        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }
            
            .sidenav {
                width: 100%;
                height: auto;
            }
            
            .event-meta {
                flex-direction: column;
            }
            
            .event-date, .event-location {
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Side Navigation -->
        <div class="sidenav">
            <div class="sidenav-header">
                <img src="<?php echo $member['profile_pic'] ? htmlspecialchars($member['profile_pic']) : 'default-profile.jpg'; ?>" alt="Profile Picture">
                <h3><?php echo htmlspecialchars($member['first_name']); ?></h3>
                <p><?php echo ucfirst($member['membership_type']); ?> Member</p>
            </div>
            
            <div class="sidenav-menu">
                <div class="nav-title">Navigation</div>
                
                <div class="nav-item">
                    <a href="member_dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="club_calendar.php" class="nav-link active">
                        <i class="fas fa-calendar-alt"></i>
                        <span>Events Calendar</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="resources.php" class="nav-link">
                        <i class="fas fa-book"></i>
                        <span>Member Resources</span>
                    </a>
                </div>
                
                <div class="nav-title">Account</div>
                
                <div class="nav-item">
                    <a href="edit_member_profile.php" class="nav-link">
                        <i class="fas fa-user-edit"></i>
                        <span>Edit Profile</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="change_password.php" class="nav-link">
                        <i class="fas fa-key"></i>
                        <span>Change Password</span>
                    </a>
                </div>
                
                <div class="nav-item">
                    <a href="membership_upgrade.php" class="nav-link">
                        <i class="fas fa-star"></i>
                        <span>Upgrade Membership</span>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="topbar">
                <h1>Events Calendar</h1>
                <div class="user-menu">
                    <img src="<?php echo $member['profile_pic'] ? htmlspecialchars($member['profile_pic']) : 'default-profile.jpg'; ?>" alt="Profile Picture">
                    <form action="logout.php" method="post">
                        <button type="submit" class="logout-btn">Logout</button>
                    </form>
                </div>
            </div>
            
            <div class="container-fluid">
                <div class="calendar-container">
                    <h2><i class="fas fa-calendar"></i> Interactive Calendar</h2>
                    <div id="calendar"></div>
                </div>
                
                <div class="events-list">
                    <h2><i class="fas fa-list"></i> Upcoming Events</h2>
                    
                    <?php if (!empty($events)): ?>
                        <?php foreach ($events as $event): ?>
                            <div class="event-card">
                                <h3 class="event-title"><?php echo htmlspecialchars($event['event_name']); ?></h3>
                                <div class="event-meta">
                                    <div class="event-date">
                                        <i class="fas fa-clock"></i>
                                        <?php echo date('F j, Y g:i a', strtotime($event['event_date'])); ?>
                                    </div>
                                    <?php if (!empty($event['location'])): ?>
                                    <div class="event-location">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <?php echo htmlspecialchars($event['location']); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($event['description'])): ?>
                                <div class="event-description">
                                    <?php echo nl2br(htmlspecialchars($event['description'])); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-events">
                            <p>No upcoming events scheduled.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- FullCalendar JS -->
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Prepare events data for FullCalendar
            const eventsData = [
                <?php foreach ($events as $event): ?>
                {
                    title: '<?php echo addslashes($event['event_name']); ?>',
                    start: '<?php echo date('Y-m-d\TH:i:s', strtotime($event['event_date'])); ?>',
                    description: '<?php echo addslashes($event['description']); ?>',
                    location: '<?php echo addslashes($event['location']); ?>',
                    extendedProps: {
                        creator: '<?php echo addslashes($event['created_by']); ?>'
                    }
                },
                <?php endforeach; ?>
            ];

            // Initialize calendar
            const calendarEl = document.getElementById('calendar');
            const calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                events: eventsData,
                eventClick: function(info) {
                    // Create event details popup
                    let details = `
                        <h3>${info.event.title}</h3>
                        <p><strong>Date:</strong> ${info.event.start.toLocaleString()}</p>
                    `;
                    
                    if (info.event.extendedProps.location) {
                        details += `<p><strong>Location:</strong> ${info.event.extendedProps.location}</p>`;
                    }
                    
                    if (info.event.extendedProps.description) {
                        details += `<p><strong>Description:</strong> ${info.event.extendedProps.description}</p>`;
                    }
                    
                    if (info.event.extendedProps.creator) {
                        details += `<p><strong>Created by:</strong> ${info.event.extendedProps.creator}</p>`;
                    }
                    
                    alert(details);
                }
            });

            calendar.render();
        });
    </script>
</body>
</html>