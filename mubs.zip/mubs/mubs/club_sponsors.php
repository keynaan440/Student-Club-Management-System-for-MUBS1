<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'club_admin') {
    header("Location: login.php");
    exit();
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');     
define('DB_NAME', 'keynan');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get club information
$username = $_SESSION['username'];
$club_name = "Your Club";
$result = $conn->query("SELECT club_name FROM clubs WHERE admin_username = '$username'");
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $club_name = $row['club_name'];
}
$result->free();

// Get sponsors
$sponsors = array();
$result = $conn->query("SELECT * FROM club_sponsors 
                       WHERE club_id IN (SELECT id FROM clubs WHERE admin_username = '$username')
                       ORDER BY sponsorship_date DESC");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $sponsors[] = $row;
    }
}
$result->free();

// Get sponsor statistics
$total_sponsors = 0;
$total_sponsorship = 0;
$active_sponsors = 0;

$result = $conn->query("SELECT COUNT(*) AS count, SUM(amount) AS total 
                       FROM club_sponsors 
                       WHERE club_id IN (SELECT id FROM clubs WHERE admin_username = '$username')");
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $total_sponsors = $row['count'];
    $total_sponsorship = $row['total'] ?? 0;
}
$result->free();

$result = $conn->query("SELECT COUNT(*) AS count FROM club_sponsors 
                       WHERE club_id IN (SELECT id FROM clubs WHERE admin_username = '$username')
                       AND (end_date IS NULL OR end_date >= CURDATE())");
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $active_sponsors = $row['count'];
}
$result->free();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Sponsors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .stat-card {
            text-align: center;
            padding: 20px;
        }
        .stat-card .stat-value {
            font-size: 2.5rem;
            font-weight: bold;
        }
        main {
            padding-top: 20px;
        }
        .club-header {
            background-color: #6c757d;
            color: white;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-none d-md-block sidebar">
            <div class="sidebar-sticky pt-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Club Admin</h4>
                    <div class="text-white small"><?php echo htmlspecialchars($club_name); ?></div>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="club_admin.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_members.php">
                            <i class="fas fa-users me-2"></i>Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_members.php">
                            <i class="fas fa-users me-2"></i>approve Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_events.php">
                            <i class="fas fa-calendar-alt me-2"></i>Events
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_finances.php">
                            <i class="fas fa-money-bill-wave me-2"></i>Finances
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="club_sponsors.php">
                            <i class="fas fa-handshake me-2"></i>Sponsors
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_settings.php">
                            <i class="fas fa-cog me-2"></i>Club Settings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_reports.php">
                            <i class="fas fa-chart-bar me-2"></i>Reports
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Club Sponsors</h1>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['username']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
                        <li><a class="dropdown-item" href="club_profile.php"><i class="fas fa-user me-1"></i> Profile</a></li>
                        <li><a class="dropdown-item" href="club_settings.php"><i class="fas fa-cog me-1"></i> Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a></li>
                    </ul>
                </div>
            </div>

            <!-- Club Header -->
            <div class="club-header">
                <h3><i class="fas fa-handshake me-2"></i><?php echo htmlspecialchars($club_name); ?> Sponsors</h3>
                <p class="mb-0">Manage your club's sponsors and partnerships.</p>
            </div>

            <!-- Stats Cards -->
            <div class="row">
                <div class="col-md-4">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h5 class="card-title">Total Sponsors</h5>
                            <div class="stat-value text-primary"><?php echo $total_sponsors; ?></div>
                            <p class="text-muted">All-time sponsors</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h5 class="card-title">Active Sponsors</h5>
                            <div class="stat-value text-success"><?php echo $active_sponsors; ?></div>
                            <p class="text-muted">Current sponsors</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h5 class="card-title">Total Sponsorship</h5>
                            <div class="stat-value text-info">$<?php echo number_format($total_sponsorship, 2); ?></div>
                            <p class="text-muted">All-time contributions</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sponsors Table -->
            <div class="card mt-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-list me-2"></i>Sponsors List</h5>
                    <a href="add_sponsor.php" class="btn btn-sm btn-primary">
                        <i class="fas fa-plus me-1"></i>Add Sponsor
                    </a>
                </div>
                <div class="card-body">
                    <?php if (!empty($sponsors)): ?>
                        <div class="table-responsive">
                            <table class="table table-striped" id="sponsorsTable">
                                <thead>
                                    <tr>
                                        <th>Sponsor Name</th>
                                        <th>Contact</th>
                                        <th>Amount</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($sponsors as $sponsor): 
                                        $status = '';
                                        $statusClass = '';
                                        if ($sponsor['end_date'] === null || strtotime($sponsor['end_date']) >= time()) {
                                            $status = 'Active';
                                            $statusClass = 'badge bg-success';
                                        } else {
                                            $status = 'Expired';
                                            $statusClass = 'badge bg-secondary';
                                        }
                                    ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($sponsor['sponsor_name']); ?></td>
                                            <td><?php echo htmlspecialchars($sponsor['contact_email']); ?></td>
                                            <td>$<?php echo number_format($sponsor['amount'], 2); ?></td>
                                            <td><?php echo date('M j, Y', strtotime($sponsor['sponsorship_date'])); ?></td>
                                            <td><?php echo $sponsor['end_date'] ? date('M j, Y', strtotime($sponsor['end_date'])) : 'N/A'; ?></td>
                                            <td><span class="<?php echo $statusClass; ?>"><?php echo $status; ?></span></td>
                                            <td>
                                                <a href="view_sponsor.php?id=<?php echo $sponsor['id']; ?>" class="btn btn-sm btn-info" title="View">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="edit_sponsor.php?id=<?php echo $sponsor['id']; ?>" class="btn btn-sm btn-warning" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>No sponsors found. Add your first sponsor to get started.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#sponsorsTable').DataTable({
            "pageLength": 10,
            "responsive": true
        });
    });
</script>
</body>
</html>