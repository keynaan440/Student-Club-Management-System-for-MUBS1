<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'club_admin') {
    header("Location: login.php");
    exit();
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'keynan');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get club information
$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT id, club_name FROM clubs WHERE admin_username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $club_id = $row['id'];
    $club_name = $row['club_name'];
} else {
    die("Error: Club not found for this admin.");
}
$stmt->close();

// Handle event deletion
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'delete') {
        $event_id = intval($_POST['event_id']);
        $stmt = $conn->prepare("DELETE FROM club_events WHERE id = ? AND club_id = ?");
        $stmt->bind_param("ii", $event_id, $club_id);
        
        if ($stmt->execute()) {
            $success_message = "Event deleted successfully!";
        } else {
            $error_message = "Error deleting event: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Get all events for this club
$events_query = "SELECT * FROM club_events WHERE club_id = ? ORDER BY event_date DESC";
$stmt = $conn->prepare($events_query);
$stmt->bind_param("i", $club_id);
$stmt->execute();
$events_result = $stmt->get_result();

// Get event statistics
$stats_query = "SELECT 
    COUNT(*) as total_events,
    SUM(CASE WHEN event_date > NOW() THEN 1 ELSE 0 END) as upcoming_events,
    SUM(CASE WHEN event_date <= NOW() THEN 1 ELSE 0 END) as past_events
    FROM club_events WHERE club_id = ?";
$stmt_stats = $conn->prepare($stats_query);
$stmt_stats->bind_param("i", $club_id);
$stmt_stats->execute();
$stats_result = $stmt_stats->get_result();
$stats = $stats_result->fetch_assoc();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Events - <?php echo htmlspecialchars($club_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .stat-card {
            text-align: center;
            padding: 15px;
        }
        .stat-card .stat-value {
            font-size: 2rem;
            font-weight: bold;
        }
        .event-card {
            transition: transform 0.2s;
        }
        .event-card:hover {
            transform: translateY(-5px);
        }
        .upcoming-event {
            border-left: 4px solid #28a745;
        }
        .past-event {
            border-left: 4px solid #6c757d;
            opacity: 0.8;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-none d-md-block sidebar">
            <div class="sidebar-sticky pt-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Club Admin</h4>
                    <div class="text-white small"><?php echo htmlspecialchars($club_name); ?></div>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="club_admin.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="club_members.php">
                            <i class="fas fa-users me-2"></i>Members
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="club_events.php">
                            <i class="fas fa-calendar-alt me-2"></i>Events
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="create_event.php">
                            <i class="fas fa-calendar-plus me-2"></i>Create Event
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="fas fa-calendar-alt me-2"></i>Club Events</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="create_event.php" class="btn btn-primary">
                        <i class="fas fa-calendar-plus me-1"></i>Create Event
                    </a>
                </div>
            </div>

            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i><?php echo $success_message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i><?php echo $error_message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Event Statistics -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h6 class="card-title">Total Events</h6>
                            <div class="stat-value text-primary"><?php echo $stats['total_events'] ?? 0; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h6 class="card-title">Upcoming Events</h6>
                            <div class="stat-value text-success"><?php echo $stats['upcoming_events'] ?? 0; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stat-card">
                        <div class="card-body">
                            <h6 class="card-title">Past Events</h6>
                            <div class="stat-value text-secondary"><?php echo $stats['past_events'] ?? 0; ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Events List -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">All Events</h5>
                </div>
                <div class="card-body">
                    <?php if ($events_result->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table id="eventsTable" class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Event Name</th>
                                        <th>Date & Time</th>
                                        <th>Location</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($event = $events_result->fetch_assoc()): 
                                        $is_upcoming = strtotime($event['event_date']) > time();
                                    ?>
                                    <tr class="<?php echo $is_upcoming ? 'upcoming-event' : 'past-event'; ?>">
                                        <td>
                                            <strong><?php echo htmlspecialchars($event['event_name']); ?></strong>
                                            <?php if (!empty($event['description'])): ?>
                                                <p class="text-muted mb-0"><?php echo htmlspecialchars(substr($event['description'], 0, 50)); ?>...</p>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo date('M j, Y g:i A', strtotime($event['event_date'])); ?></td>
                                        <td><?php echo htmlspecialchars($event['location'] ?? 'N/A'); ?></td>
                                        <td>
                                            <span class="badge <?php echo $is_upcoming ? 'bg-success' : 'bg-secondary'; ?>">
                                                <?php echo $is_upcoming ? 'Upcoming' : 'Past'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm" role="group">
                                                <a href="view_event.php?id=<?php echo $event['id']; ?>" class="btn btn-outline-primary">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="edit_event.php?id=<?php echo $event['id']; ?>" class="btn btn-outline-warning">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteEventModal" 
                                                    onclick="setDeleteModal(<?php echo $event['id']; ?>, '<?php echo htmlspecialchars($event['event_name']); ?>')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info text-center">
                            <i class="fas fa-calendar fa-3x mb-3 text-muted"></i>
                            <h5>No Events Found</h5>
                            <p>Your club doesn't have any events yet. Create your first event!</p>
                            <a href="create_event.php" class="btn btn-primary">
                                <i class="fas fa-calendar-plus me-1"></i>Create First Event
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteEventModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete <strong id="delete_event_name"></strong>?</p>
                <p class="text-danger"><small>This action cannot be undone.</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="event_id" id="delete_event_id">
                    <button type="submit" class="btn btn-danger">Delete Event</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    <?php if ($events_result->num_rows > 0): ?>
    $('#eventsTable').DataTable({
        "pageLength": 10,
        "order": [[1, "desc"]],
        "columnDefs": [
            { "orderable": false, "targets": [4] }
        ]
    });
    <?php endif; ?>
});

function setDeleteModal(eventId, eventName) {
    document.getElementById('delete_event_id').value = eventId;
    document.getElementById('delete_event_name').textContent = eventName;
}
</script>
</body>
</html>